import time
import math
from periphery import I2C
from threading import Lock

class PCA9685:
    # Registers/etc.
    __SUBADR1 = 0x02
    __SUBADR2 = 0x03
    __SUBADR3 = 0x04
    __MODE1 = 0x00
    __PRESCALE = 0xFE
    __LED0_ON_L = 0x06
    __LED0_ON_H = 0x07
    __LED0_OFF_L = 0x08
    __LED0_OFF_H = 0x09
    __ALLLED_ON_L = 0xFA
    __ALLLED_ON_H = 0xFB
    __ALLLED_OFF_L = 0xFC
    __ALLLED_OFF_H = 0xFD

    def __init__(self, device, lock, address=0x40):
        self.address = address
        self.lock = lock
        self.bus = device
        self.write(self.__MODE1, 0x00)

    def write(self, reg, value):
        msgs = [I2C.Message([reg, value])]
        try:
            self.bus.transfer(self.address, msgs)
        except Exception as e:
            print(f"Error write byte: {e}")
            return -1
        return 0

    def read(self, reg):
        write_msg = I2C.Message([reg])
        read_msg = I2C.Message([0], read=True)
        try:
            self.bus.transfer(self.address, [write_msg, read_msg])
            return read_msg.data[0]
        except Exception as e:
            print(f"Error read byte: {e}")
            return -1

    def setPWMFreq(self, freq):
        freq *= 1.022
        prescaleval = 25000000.0  # 25MHz
        prescaleval /= 4096.0
        prescaleval /= freq
        prescaleval -= 1.0
        prescale = math.floor(prescaleval + 0.5)
        oldmode = self.read(self.__MODE1)
        newmode = (oldmode & 0x7F) | 0x10
        self.write(self.__MODE1, newmode)
        self.write(self.__PRESCALE, int(math.floor(prescale)))
        self.write(self.__MODE1, oldmode)
        time.sleep(0.005)
        self.write(self.__MODE1, oldmode | 0x80)

    def setPWM(self, channel, on, off):
        with self.lock:
            self.write(self.__LED0_ON_L + 4 * channel, on & 0xFF)
            self.write(self.__LED0_ON_H + 4 * channel, on >> 8)
            self.write(self.__LED0_OFF_L + 4 * channel, off & 0xFF)
            self.write(self.__LED0_OFF_H + 4 * channel, off >> 8)

    # 0-180
    def setServoPulse(self, channel, pulse):
        pulse = int(2.275 * (45 + pulse))
        self.setPWM(channel, 0, pulse)

    # 500-2500
    def setServoPulse_propeller(self, channel, pulse):
        pulse = int(4096 * (pulse) / 20000)
        self.setPWM(channel, 0, pulse)

if __name__ == '__main__':
    # 初始化I2C设备和锁
    i2c_device = I2C("/dev/i2c-2")  # 根据实际情况调整I2C设备路径
    lock = Lock()
    
    # 创建PCA9685实例
    pca = PCA9685(i2c_device, lock)
    
    # 设置PWM频率（通常舵机使用50Hz）
    pca.setPWMFreq(50)
    
    print("PCA9685 PWM控制器已初始化")
    print("输入格式: 通道号,脉冲宽度 (例如: 0,1600)")
    print("通道号范围: 0-15")
    print("脉冲宽度范围: 500-2500 us")
    print("输入 'q' 退出程序")
    
    pca.setServoPulse(1,0)
    
    def pwm_init(pwm):
        pwm.setPWMFreq(50)
        for i in range(8):
            pwm.setServoPulse_propeller(i, 1500)
        print("init success")
        
    pwm_init(pca)
    
    while True:
        try:
            user_input = input("\n请输入通道号和脉冲宽度: ").strip()
            
            if user_input.lower() == 'q':
                print("退出程序")
                break
            
            # 分割输入参数
            parts = user_input.split(',')
            if len(parts) != 2:
                print("错误: 请输入格式: 通道号,脉冲宽度 (例如: 0,1600)")
                continue
            
            # 解析通道号和脉冲宽度
            channel = int(parts[0])
            pulse_width = int(parts[1])
            
            # 验证通道号范围
            if channel < 0 or channel > 15:
                print("错误: 通道号必须在 0-15 范围内")
                continue
            
            # 验证脉冲宽度范围
            if pulse_width < 500 or pulse_width > 2500:
                print("错误: 脉冲宽度必须在 500-2500 us 范围内")
                continue
            
            # 设置PWM脉冲
            pca.setServoPulse_propeller(channel, pulse_width)
            print(f"已设置通道 {channel} 的PWM脉冲为 {pulse_width}us")
            
        except ValueError:
            print("错误: 请输入有效的数字")
        except KeyboardInterrupt:
            print("\n程序被用户中断")
            break
        except Exception as e:
            print(f"发生错误: {e}")
    
    # 清理资源
    i2c_device.close()