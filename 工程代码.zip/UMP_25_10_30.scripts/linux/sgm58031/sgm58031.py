from enum import IntEnum
from periphery import I2C
import time

class SGM58031:
    """SGM58031 16位ADC驱动"""
    
    # 寄存器地址
    REG_CONVERSION = 0x00
    REG_CONFIG     = 0x01
    REG_LO_THRESH  = 0x02
    REG_HI_THRESH  = 0x03
    
    # 默认I2C地址
    DEFAULT_ADDRESS = 0x48
    
    class MUX(IntEnum):
        """输入通道配置"""
        AINP_AIN0_AINN_AIN1 = 0x0000  # Differential P=AIN0, N=AIN1 (Default)
        AINP_AIN0_AINN_AIN3 = 0x1000  # Differential P=AIN0, N=AIN3
        AINP_AIN1_AINN_AIN3 = 0x2000  # Differential P=AIN1, N=AIN3
        AINP_AIN2_AINN_AIN3 = 0x3000  # Differential P=AIN2, N=AIN3
        AINP_AIN0_AINN_GND  = 0x4000  # Single-ended P=AIN0, N=GND
        AINP_AIN1_AINN_GND  = 0x5000  # Single-ended P=AIN1, N=GND
        AINP_AIN2_AINN_GND  = 0x6000  # Single-ended P=AIN2, N=GND
        AINP_AIN3_AINN_GND  = 0x7000  # Single-ended P=AIN3, N=GND

    class PGA(IntEnum):
        """可编程增益放大器设置"""
        FS_6_144V = 0x0000  # ±6.144V range = Gain 2/3
        FS_4_096V = 0x0200  # ±4.096V range = Gain 1
        FS_2_048V = 0x0400  # ±2.048V range = Gain 2 (Default)
        FS_1_024V = 0x0600  # ±1.024V range = Gain 4
        FS_0_512V = 0x0800  # ±0.512V range = Gain 8
        FS_0_256V = 0x0A00  # ±0.256V range = Gain 16

    class DR(IntEnum):
        """数据速率 (Samples per second)"""
        SPS_8   = 0x0000
        SPS_16  = 0x0020
        SPS_32  = 0x0040
        SPS_64  = 0x0060
        SPS_128 = 0x0080  # (Default)
        SPS_250 = 0x00A0
        SPS_475 = 0x00C0
        SPS_860 = 0x00E0

    class MODE(IntEnum):
        """操作模式"""
        CONTINUOUS = 0x0000
        SINGLE     = 0x0001  # (Default)

    class OS(IntEnum):
        """单次转换启动位"""
        IDLE    = 0x0000
        CONVERT = 0x8000

    class COMP(IntEnum):
        """比较器配置"""
        TRADITIONAL = 0x0000
        WINDOW      = 0x0010

    class COMP_POL(IntEnum):
        """比较器极性"""
        ACTIVE_LOW  = 0x0000
        ACTIVE_HIGH = 0x0008

    class COMP_LAT(IntEnum):
        """比较器锁存"""
        NON_LATCHING = 0x0000
        LATCHING     = 0x0004

    class COMP_QUE(IntEnum):
        """比较器队列"""
        CONV_1 = 0x0000  # 1次转换后触发
        CONV_2 = 0x0001  # 2次转换后触发
        CONV_4 = 0x0002  # 4次转换后触发
        DISABLE = 0x0003  # 禁用比较器

    def __init__(self, device, i2c_address=DEFAULT_ADDRESS):
        """
        初始化SGM58031
        
        参数:
            device: I2C设备路径或对象
            i2c_address: I2C设备地址
        """
        if isinstance(device, str):
            self.i2c = I2C(device)
        else:
            self.i2c = device
            
        self.i2c_address = i2c_address
        
        # 默认配置
        self.config = (
            self.OS.CONVERT |          # 启动单次转换
            self.MUX.AINP_AIN0_AINN_AIN1 |  # 差分输入 AIN0, AIN1
            self.PGA.FS_2_048V |       # ±2.048V 量程
            self.MODE.SINGLE |         # 单次转换模式
            self.DR.SPS_128 |          # 128 SPS
            self.COMP.TRADITIONAL |    # 传统比较器模式
            self.COMP_POL.ACTIVE_LOW | # 低电平有效
            self.COMP_LAT.NON_LATCHING | # 非锁存模式
            self.COMP_QUE.DISABLE      # 禁用比较器
        )
        
        # 验证设备连接并写入配置
        self._verify_device()
        self._write_config()
        
        # PGA设置对应的满量程电压
        self._pga_voltage_map = {
            self.PGA.FS_6_144V: 6.144,
            self.PGA.FS_4_096V: 4.096,
            self.PGA.FS_2_048V: 2.048,
            self.PGA.FS_1_024V: 1.024,
            self.PGA.FS_0_512V: 0.512,
            self.PGA.FS_0_256V: 0.256
        }

    def _verify_device(self):
        """验证设备是否存在"""
        try:
            # 尝试读取配置寄存器
            config = self._read_register(self.REG_CONFIG)
            print(f"设备检测成功，配置寄存器: 0x{config:04x}")
        except Exception as e:
            raise Exception(f"无法访问SGM58031设备 (地址0x{self.i2c_address:02x}): {e}")

    def _write_register(self, register, data):
        """写入数据到指定寄存器"""
        write_data = [register, (data >> 8) & 0xFF, data & 0xFF]
        messages = [I2C.Message(write_data)]
        try:
            self.i2c.transfer(self.i2c_address, messages)
        except Exception as e:
            raise Exception(f"写入寄存器 0x{register:02x} 失败: {e}")

    def _read_register(self, register, length=2):
        """从指定寄存器读取数据"""
        write_msg = I2C.Message([register])
        read_msg = I2C.Message([0] * length, read=True)
        messages = [write_msg, read_msg]
        
        try:
            self.i2c.transfer(self.i2c_address, messages)
        except Exception as e:
            raise Exception(f"读取寄存器 0x{register:02x} 失败: {e}")
        
        if length == 2:
            return (read_msg.data[0] << 8) | read_msg.data[1]
        else:
            return read_msg.data

    def _write_config(self):
        """写入配置寄存器"""
        self._write_register(self.REG_CONFIG, self.config)

    def _wait_for_conversion(self, timeout=0.1):
        """
        等待单次转换完成
        
        参数:
            timeout: 超时时间(秒)
        """
        start_time = time.time()
        while time.time() - start_time < timeout:
            config_reg = self._read_register(self.REG_CONFIG)
            # 检查OS位，为0表示转换完成
            if not (config_reg & self.OS.CONVERT):
                return True
            time.sleep(0.001)
        
        raise Exception("ADC转换超时")

    def _twos_complement(self, value, bits):
        """计算二进制补码"""
        if value & (1 << (bits - 1)):
            value -= (1 << bits)
        return value

    def set_config(self, mux=None, pga=None, dr=None, mode=None, 
                   comp_que=None, comp_pol=None, comp_lat=None, comp_mode=None):
        """
        修改配置参数
        
        参数:
            mux: 输入通道 (MUX 枚举值)
            pga: 增益设置 (PGA 枚举值)
            dr: 数据速率 (DR 枚举值)
            mode: 操作模式 (MODE 枚举值)
            comp_que: 比较器队列 (COMP_QUE 枚举值)
            comp_pol: 比较器极性 (COMP_POL 枚举值)
            comp_lat: 比较器锁存 (COMP_LAT 枚举值)
            comp_mode: 比较器模式 (COMP 枚举值)
        """
        # 保存当前的OS位状态
        current_os = self.config & self.OS.CONVERT
        
        # 更新配置
        if mux is not None:
            self.config = (self.config & ~0x7000) | mux
        if pga is not None:
            self.config = (self.config & ~0x0E00) | pga
        if dr is not None:
            self.config = (self.config & ~0x00E0) | dr
        if mode is not None:
            self.config = (self.config & ~0x0001) | mode
        if comp_que is not None:
            self.config = (self.config & ~0x0003) | comp_que
        if comp_pol is not None:
            self.config = (self.config & ~0x0008) | comp_pol
        if comp_lat is not None:
            self.config = (self.config & ~0x0004) | comp_lat
        if comp_mode is not None:
            self.config = (self.config & ~0x0010) | comp_mode
        
        # 恢复OS位状态
        self.config |= current_os
        
        self._write_config()

    def get_config(self):
        """读取当前配置寄存器值"""
        return self._read_register(self.REG_CONFIG)

    def read_raw(self):
        """读取原始16位ADC值"""
        # 在单次转换模式下，需要启动新的转换并等待完成
        if self.config & self.MODE.SINGLE:
            # 设置OS位启动转换
            self.config |= self.OS.CONVERT
            self._write_config()
            # 等待转换完成
            self._wait_for_conversion()
        
        # 读取转换结果
        raw_value = self._read_register(self.REG_CONVERSION)
        return self._twos_complement(raw_value, 16)

    def read_voltage(self):
        """
        读取电压值 (单位: 伏特)
        
        返回:
            float: 测量到的电压值
        """
        # 获取当前PGA设置
        pga_setting = self.config & 0x0E00
        full_scale_voltage = self._pga_voltage_map.get(pga_setting, 2.048)  # 默认2.048V
        
        raw = self.read_raw()
        # 计算电压: (原始值 / 32768) * 满量程电压
        voltage = (raw / 32768.0) * full_scale_voltage
        return voltage

    def set_thresholds(self, low_thresh, high_thresh):
        """
        设置比较器阈值
        
        参数:
            low_thresh: 低阈值 (原始ADC值)
            high_thresh: 高阈值 (原始ADC值)
        """
        self._write_register(self.REG_LO_THRESH, low_thresh & 0xFFFF)
        self._write_register(self.REG_HI_THRESH, high_thresh & 0xFFFF)

    def get_thresholds(self):
        """读取比较器阈值"""
        low_thresh = self._twos_complement(
            self._read_register(self.REG_LO_THRESH), 16
        )
        high_thresh = self._twos_complement(
            self._read_register(self.REG_HI_THRESH), 16
        )
        return low_thresh, high_thresh

    def close(self):
        """关闭I2C连接"""
        self.i2c.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# 使用示例
if __name__ == "__main__":
    # 使用方法1: 使用上下文管理器
    with SGM58031(device="/dev/i2c-2", i2c_address=0x48) as adc:
        # 配置为单端输入 AIN0
        adc.set_config(
            mux=SGM58031.MUX.AINP_AIN0_AINN_GND,
            pga=SGM58031.PGA.FS_6_144V,
            dr=SGM58031.DR.SPS_128
        )
        
        print("SGM58031 ADC测试")
        print("=" * 40)
        
        for i in range(10):
            raw_value = adc.read_raw()
            voltage = adc.read_voltage()
            
            print(f"采样 {i+1}: 原始值 = {raw_value:6d}, 电压 = {voltage:+.6f} V")
            time.sleep(0.1)