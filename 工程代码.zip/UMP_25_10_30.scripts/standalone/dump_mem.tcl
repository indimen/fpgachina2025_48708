# dump_mem_dec.tcl
# 从 DDR 地址读取 32-bit 数据，逐个把 hex -> decimal 写入文件（每行一个十进制数）

# 连接并选中目标（根据你的板子名称可删改 filter）
connect
targets -set -filter {name =~ "PSU*"}

# =========== 参数（按需修改） ===========
set start_addr 0x10900000
set total_words 168750        ;# 一共要读取多少个 32-bit word
set batch_size 1024           ;# 每次 mrd 读取的 word 数，避免一次读太多
set outpath "E:/FPGA_Ultra96/UMP_25_10_30/UMP_25_10_30.scripts/output_dec.txt"
# ========================================

puts "Start dumping from [format 0x%08X $start_addr], total words: $total_words"

# 打开输出文件（写模式）
set fout [open $outpath w]

# 批量读取循环
for {set i 0} {$i < $total_words} {incr i $batch_size} {
    set cur_addr [expr {$start_addr + $i * 4}]
    set remaining [expr {$total_words - $i}]
    if {$remaining > $batch_size} {
        set count $batch_size
    } else {
        set count $remaining
    }

    puts "Reading from [format 0x%08X $cur_addr] ($count words)..."
    # mrd 返回一个列表，每项通常是类似 "0x10900000: 12345678" 的字符串
    set vals [mrd $cur_addr $count]

    # 解析每一行，提取十六进制数并转成十进制写入文件
    foreach line $vals {
        # 先尝试用正则抽取 "0x...: 0x...." 形式中的右侧值
        if {[regexp {0x[0-9A-Fa-f]+:\s*(0x[0-9A-Fa-f]+)} $line -> hexval]} {
            # hexval 类似 "0x1234ABCD"
            set dec [expr {$hexval}]
            puts $fout $dec
        } else {
            # 备用解析：split 并取第二个 token（有些版本 mrd 返回格式不一样）
            set toks [split $line]
            if {[llength $toks] >= 2} {
                set hexval [lindex $toks 1]
                # 仍需确保 hexval 是 0x... 形式
                if {[string match 0x* $hexval]} {
                    set dec [expr {$hexval}]
                    puts $fout $dec
                } else {
                    # 若非十六进制，直接写原始字符串以便排查
                    puts $fout $hexval
                }
            } else {
                # 未解析到，写原行以便调试
                puts $fout $line
            }
        }
    }
}

close $fout
puts "✅ Done. Saved decimal output to: $outpath"
