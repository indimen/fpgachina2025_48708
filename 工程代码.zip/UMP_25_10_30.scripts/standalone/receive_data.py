# ...existing code...
import serial
import time

# 串口配置
COM_PORT = 'COM7'
BAUD_RATE = 115200
PIXEL_COUNT = 168750
TRIGGER_TEXT = b'Extracting 6-bit disparity from 32-bit DMA data...'

def main():
    # 打开串口
    ser = serial.Serial(COM_PORT, BAUD_RATE, timeout=1)
    print(f"Opened {COM_PORT} at {BAUD_RATE} baud")

    buffer = b""
    found_trigger = False

    print("Waiting for trigger message from FPGA...")
    while True:
        line = ser.readline()
        if not line:
            continue
        buffer += line
        print(line.decode(errors='ignore').strip())

        # 检查触发标识
        if TRIGGER_TEXT in buffer:
            found_trigger = True
            break

    print("Trigger detected, start receiving disparity data...")

    disparity_data = bytearray()
    # 当数据长期没有到达时提前退出并写出已有数据
    inactivity_timeout = 5.0  # 秒，超过此时间无新数据则停止
    last_received_time = time.monotonic()

    while len(disparity_data) < PIXEL_COUNT:
        # 每次最多读 1024 字节以避免一次性阻塞过久
        to_read = min(1024, PIXEL_COUNT - len(disparity_data))
        chunk = ser.read(to_read)
        if chunk:
            disparity_data.extend(chunk)
            last_received_time = time.monotonic()
            print(f"\rReceived {len(disparity_data)}/{PIXEL_COUNT} bytes", end='')
        else:
            # 如果在 inactivity_timeout 秒内没有收到任何数据，则认为链路已经停止
            if time.monotonic() - last_received_time > inactivity_timeout:
                print(f"\nNo data received for {inactivity_timeout} seconds, stopping early.")
                break
            # 否则继续等待（ser.timeout 已设置为 1 秒）
            continue

    print(f"\nReceived total {len(disparity_data)} bytes. Writing to output.txt...")

    # 写入文本文件，每个像素一行（即使未收到全部像素也写出已有数据）
    with open("output.txt", "w") as f:
        for value in disparity_data:
            f.write(f"{value}\n")

    print("Saved disparity values to output.txt")
    ser.close()

if __name__ == "__main__":
    main()
# ...existing code...