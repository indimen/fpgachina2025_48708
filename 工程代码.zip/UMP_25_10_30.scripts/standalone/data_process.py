import re

def process_file(input_file, output_file):
    """
    处理文件：删除地址行，将十六进制数据转换为十进制并排成一列
    """
    decimal_values = []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 使用正则表达式匹配十六进制数据行（以8个十六进制字符组成的行）
    hex_pattern = r'^[0-9A-Fa-f]{8}$'
    lines = content.split('\n')
    
    for line in lines:
        line = line.strip()
        # 跳过空行和地址行（包含冒号的行）
        if not line or ':' in line:
            continue
        
        # 检查是否是十六进制数据行
        if re.match(hex_pattern, line):
            try:
                # 将十六进制转换为十进制
                decimal_value = int(line, 16)
                decimal_values.append(decimal_value)
            except ValueError:
                print(f"警告: 无法转换 '{line}' 为十进制数")
    
    # 将结果写入输出文件
    with open(output_file, 'w', encoding='utf-8') as f:
        for value in decimal_values:
            f.write(f"{value}\n")
    
    print(f"处理完成! 共转换 {len(decimal_values)} 个数据")
    print(f"结果已保存到: {output_file}")
    
    # 可选：在控制台显示前20个结果作为预览
    print("\n前20个转换结果:")
    for i, value in enumerate(decimal_values[:20]):
        print(f"{i+1}: {value}")

# 使用方法
if __name__ == "__main__":
    input_filename = "output_dec_1.txt"  # 输入文件名
    output_filename = "decimal_output_1.txt"  # 输出文件名
    
    process_file(input_filename, output_filename)