#!/usr/bin/env python3
"""
生成硬编码测试数据的C头文件
从L1.txt和R1.txt读取RGB数据，生成test_data.h
"""

def parse_rgb_hex(hex_str):
    """解析十六进制RGB字符串，如 'B53131' -> (0xB5, 0x31, 0x31)"""
    hex_str = hex_str.strip()
    r = int(hex_str[0:2], 16)
    g = int(hex_str[2:4], 16)
    b = int(hex_str[4:6], 16)
    return (r, g, b)

def generate_header_file(left_file, right_file, output_file, max_pixels=None):
    """生成包含RGB数据的C头文件"""
    
    print(f"读取 {left_file}...")
    with open(left_file, 'r') as f:
        left_data = [parse_rgb_hex(line) for line in f if line.strip()]
    
    print(f"读取 {right_file}...")
    with open(right_file, 'r') as f:
        right_data = [parse_rgb_hex(line) for line in f if line.strip()]
    
    num_pixels = min(len(left_data), len(right_data))
    if max_pixels:
        num_pixels = min(num_pixels, max_pixels)
    
    print(f"生成 {output_file} ({num_pixels} 像素)...")
    
    with open(output_file, 'w') as f:
        f.write("/*\n")
        f.write(" * 自动生成的测试数据文件\n")
        f.write(f" * 包含 {num_pixels} 个像素的RGB数据\n")
        f.write(" * 格式: [0x00, 右R, 右G, 右B, 0x00, 左R, 左G, 左B] 每像素8字节\n")
        f.write(" * 总共 {} 字节\n".format(num_pixels * 8))
        f.write(" */\n\n")
        f.write("#ifndef TEST_DATA_H\n")
        f.write("#define TEST_DATA_H\n\n")
        f.write("#include \"xil_types.h\"\n\n")
        f.write(f"#define TEST_PIXEL_COUNT {num_pixels}\n")
        f.write(f"#define TEST_DATA_SIZE (TEST_PIXEL_COUNT * 8)\n\n")
        
        # 生成RGB数据数组（64bit对齐格式：0x00,右R,右G,右B,0x00,左R,左G,左B）
        f.write("// RGB数据数组: [0x00, 右R, 右G, 右B, 0x00, 左R, 左G, 左B] × {} 像素\n".format(num_pixels))
        f.write("// 每像素8字节，匹配64bit DMA传输宽度\n")
        f.write("const u8 test_rgb_data[TEST_DATA_SIZE] = {\n")
        
        # 每行6个像素（48字节）
        for i in range(0, num_pixels, 6):
            f.write("    ")
            for j in range(6):
                idx = i + j
                if idx >= num_pixels:
                    break
                
                r_r, g_r, b_r = right_data[idx]
                r_l, g_l, b_l = left_data[idx]
                
                # 格式: 0x00, 右R, 右G, 右B, 0x00, 左R, 左G, 左B
                f.write("0x00,0x{:02X},0x{:02X},0x{:02X},0x00,0x{:02X},0x{:02X},0x{:02X}".format(
                    r_r, g_r, b_r, r_l, g_l, b_l))
                
                if idx < num_pixels - 1:
                    f.write(",")
                
                if (j < 5 and idx < num_pixels - 1):
                    f.write(" ")
            
            f.write("\n")
        
        f.write("};\n\n")
        f.write("#endif // TEST_DATA_H\n")
    
    print(f"[OK] Generation complete! File size: {num_pixels * 8} bytes")

if __name__ == "__main__":
    import sys
    
    # 默认使用完整数据（168750像素）
    max_pixels = None
    
    # 如果提供命令行参数，限制像素数量（用于测试）
    if len(sys.argv) > 1:
        max_pixels = int(sys.argv[1])
        print(f"限制像素数量为: {max_pixels}")
    
    generate_header_file(
        "L1.txt",
        "R1.txt",
        "../25_10_10_v2.sdk/app_component/src/test_data.h",
        max_pixels
    )
    
    print("\n[OK] test_data.h generated!")
    print("Note: Full data (168750 pixels) will generate ~3MB header file")
    print("      This will increase compile time, but no runtime overhead")

