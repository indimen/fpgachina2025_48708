`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/10/24 01:49:27
// Design Name: 
// Module Name: TOP_PL_sim
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: RGB Stereo Vision Testbench - Reads L1.txt/R1.txt and outputs disparity
// 
// Dependencies: topPL_tb module, L1.txt, R1.txt files
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments: Based on aggr_tb structure, processes 375x450 RGB images
// 
//////////////////////////////////////////////////////////////////////////////////

module TOP_PL_sim();

    // Clock and reset signals
    
    reg clk_input;
    reg rstn;
    wire clkHigh;
    wire clkLow;
    wire locked;
    // RGB input signals
    reg [23:0] data_in_L_RGB;
    reg [23:0] data_in_R_RGB;
    reg data_in_L_valid;
    reg data_in_R_valid;
    
    // Output signals
    wire [5:0] data_out_lrc;
    wire data_out_lrc_valid;
    
    // File handles
    integer file_L_RGB, file_R_RGB, file_disparity;
    // integer file_disp_L, file_disp_R;  // 左右视差监控文件
    
    // Clock generation
    parameter CLK_HIGH_PERIOD = 5.0;  // 100MHz (high speed)
    // parameter CLK_LOW_PERIOD = 50.0;   // 10MHz (low speed)
    
    always #CLK_HIGH_PERIOD clk_input = ~clk_input;
    // always #CLK_LOW_PERIOD clkLow = ~clkLow;
    
    // Image parameters
    parameter IMAGE_WIDTH  = 450;//width pixel number 
    parameter IMAGE_HEIGHT = 375;//height row number
    parameter TOTAL_PIXELS = IMAGE_WIDTH * IMAGE_HEIGHT; // 168,750 pixels
    
    // Data buffers
    reg [23:0] current_L_RGB, current_R_RGB;
    reg [23:0] next_L_RGB, next_R_RGB;
    reg [9:0] current_row, current_col;
    reg [20:0] pixel_index; // Current pixel index (0 to TOTAL_PIXELS-1)
    reg [20:0] output_pixel_index; // Index of pixel being output
    
    // Control flags
    reg data_read_success;
    reg first_pixel_loaded;
    reg first_pixel_output_done; // Flag to ensure first pixel gets output
    reg data_transmission_active;
    reg simulation_done;
    reg files_opened;
    
    // Output monitoring
    reg [20:0] output_count;
    reg [20:0] no_output_cycles;
    parameter MAX_NO_OUTPUT_CYCLES = 2000; // Wait 500 cycles before ending
    
    //================= Initialization =================
    initial begin
        // Initialize signals
        clk_input = 0;
        rstn = 0;
        data_in_L_RGB = 24'h000000;
        data_in_R_RGB = 24'h000000;
        data_in_L_valid = 0;
        data_in_R_valid = 0;
        
        // Initialize control variables
        current_row = 1;
        current_col = 1;
        pixel_index = 0;
        output_pixel_index = 0;
        data_read_success = 1;
        first_pixel_loaded = 0;
        first_pixel_output_done = 0;
        data_transmission_active = 0;
        simulation_done = 0;
        files_opened = 0;
        output_count = 0;
        no_output_cycles = 0;
        
        // Reset sequence
        #95;
        rstn = 1;
        // 等待PLL锁定
        $display("Waiting for PLL to lock...");
        wait(locked == 1'b1);
        $display("PLL locked! Starting simulation...");
        // 额外等待几个时钟周期确保时钟稳定
        repeat(10) @(posedge clkHigh);
        
        // Open files
        file_L_RGB = $fopen("L1.txt", "r");
        file_R_RGB = $fopen("R1.txt", "r");
        file_disparity = $fopen("disparity_output.txt", "w");
        // file_disp_L = $fopen("disp_L.txt", "w");
        // file_disp_R = $fopen("disp_R.txt", "w");
        
        if(file_L_RGB == 0 || file_R_RGB == 0 || file_disparity == 0) begin
            $display("ERROR: Failed to open RGB input files or disparity output file!");
            $display("Make sure L1.txt and R1.txt are in simulation directory");
            $stop;
        end else begin
            files_opened = 1;
            $display("=== RGB Stereo Vision Simulation Started ===");
            $display("Processing %d pixels (%dx%d)...", TOTAL_PIXELS, IMAGE_WIDTH, IMAGE_HEIGHT);
            $display("Input files: L1.txt, R1.txt (RGB format)");
            $display("Output files: disparity_output.txt, disp_L.txt, disp_R.txt");
            $display("================================================");
        end
    end
    
    //================= RGB Data Reading Logic =================
    reg [23:0] rgb_temp_L, rgb_temp_R;
    
    always @(posedge clkLow or negedge rstn) begin
        if(!rstn) begin
            current_L_RGB <= 24'h000000;
            current_R_RGB <= 24'h000000;
            next_L_RGB <= 24'h000000;
            next_R_RGB <= 24'h000000;
            current_row <= 1;
            current_col <= 1;
            pixel_index <= 0;
            output_pixel_index <= 0;
            first_pixel_loaded <= 0;
            first_pixel_output_done <= 0;
            data_transmission_active <= 0;
        end
        else if(files_opened && !simulation_done) begin
            // Preload first two pixels for double buffering
            if(!first_pixel_loaded) begin
                // Read first pixel from both files
                if($fscanf(file_L_RGB, "%6h", rgb_temp_L) == 1 && 
                   $fscanf(file_R_RGB, "%6h", rgb_temp_R) == 1) begin
                    current_L_RGB <= rgb_temp_L;
                    current_R_RGB <= rgb_temp_R;
                    $display("Loaded first pixel (index 0): L=%06h, R=%06h", rgb_temp_L, rgb_temp_R);
                    
                    // Preload second pixel
                    if($fscanf(file_L_RGB, "%6h", rgb_temp_L) == 1 && 
                       $fscanf(file_R_RGB, "%6h", rgb_temp_R) == 1) begin
                        next_L_RGB <= rgb_temp_L;
                        next_R_RGB <= rgb_temp_R;
                        first_pixel_loaded <= 1;
                        pixel_index <= 1; // Next pixel in buffer is index 1
                        output_pixel_index <= 0; // Ready to output pixel 0
                        $display("Preloaded second pixel (index 1): L=%06h, R=%06h", rgb_temp_L, rgb_temp_R);
                    end else begin
                        // Only one pixel in file or read error
                        first_pixel_loaded <= 1;
                        output_pixel_index <= 0;
                        pixel_index <= 0;
                        $display("Only first pixel available or read error for second pixel");
                    end
                end else begin
                    data_read_success <= 0;
                    $display("Failed to load first pixel");
                end
            end
            else if(data_read_success && data_transmission_active) begin
                // Normal pixel advancement (including first pixel)
                // Update pixel coordinates for current output pixel
                if(current_col == IMAGE_WIDTH) begin
                    current_row <= current_row + 1;
                    current_col <= 1;
                end else begin
                    current_col <= current_col + 1;
                end
                
                // Advance output pixel index
                output_pixel_index <= output_pixel_index + 1;
                
                // Move next pixel to current position
                current_L_RGB <= next_L_RGB;
                current_R_RGB <= next_R_RGB;
                
                // Mark first pixel as processed (for consistency)
                if(!first_pixel_output_done) begin
                    first_pixel_output_done <= 1;
                    $display("First pixel processed, advancing to next");
                end
                
                // Read new next pixel (if available)
                if(pixel_index < TOTAL_PIXELS - 1) begin
                    if($fscanf(file_L_RGB, "%6h", rgb_temp_L) == 1 && 
                       $fscanf(file_R_RGB, "%6h", rgb_temp_R) == 1) begin
                        next_L_RGB <= rgb_temp_L;
                        next_R_RGB <= rgb_temp_R;
                        pixel_index <= pixel_index + 1;
                        $display("Read next pixel %d: L=%06h, R=%06h", pixel_index + 1, rgb_temp_L, rgb_temp_R);
                    end else begin
                        data_read_success <= 0;
                        $display("Failed to read pixel %d", pixel_index + 1);
                    end
                end else begin
                    // No more pixels to read
                    $display("Processing pixel %d (last available)", output_pixel_index + 1);
                    if(output_pixel_index >= TOTAL_PIXELS - 1) begin
                        data_read_success <= 0;
                        $display("All %d pixels have been processed", TOTAL_PIXELS);
                    end
                end
            end
        end
    end
    
    //================= Valid Signal Generation =================
    
    always @(posedge clkLow or negedge rstn) begin
        if(!rstn) begin
            data_transmission_active <= 0;
        end
        else if(first_pixel_loaded && !data_transmission_active) begin
            data_transmission_active <= 1;
            $display("Starting data transmission at time %0t", $time);
        end
        else if(output_pixel_index >= TOTAL_PIXELS) begin
            data_transmission_active <= 0;
            $display("Stopping data transmission - all %d pixels sent", TOTAL_PIXELS);
        end
    end
    
    // Output RGB data and valid signals
    always @(*) begin
        if(rstn && data_transmission_active && output_pixel_index < TOTAL_PIXELS) begin
            data_in_L_RGB = current_L_RGB;
            data_in_R_RGB = current_R_RGB;
            data_in_L_valid = 1'b1;
            data_in_R_valid = 1'b1;
        end else begin
            data_in_L_RGB = 24'h000000;
            data_in_R_RGB = 24'h000000;
            data_in_L_valid = 1'b0;
            data_in_R_valid = 1'b0;
        end
    end
    
    //================= Output Monitoring =================
    reg data_out_lrc_valid_prev;
    
    always @(posedge clkHigh or negedge rstn) begin
        if(!rstn) begin
            output_count <= 0;
            no_output_cycles <= 0;
            simulation_done <= 0;
            data_out_lrc_valid_prev <= 0;
        end else begin
            data_out_lrc_valid_prev <= data_out_lrc_valid;
            
            // Detect valid disparity output
            if(data_out_lrc_valid && !data_out_lrc_valid_prev) begin
                // Write disparity to file (only the value, no extra content)
                $fwrite(file_disparity, "%d\n", data_out_lrc);
                output_count <= output_count + 1;
                no_output_cycles <= 0; // Reset no-output counter
                
                // Progress display every 1000 outputs
                if(output_count % 1000 == 0 && output_count > 0) begin
                    $display("Progress: %d disparity values written...", output_count + 1);
                end
            end else begin
                // Count cycles without output
                no_output_cycles <= no_output_cycles + 1;
            end
            
            if(no_output_cycles >= MAX_NO_OUTPUT_CYCLES && output_count > 0) begin  // 新增：收到所有预期输出
                simulation_done <= 1;
                $display("=== Simulation Complete ===");
                $display("Total disparity values written: %d", output_count);
                if(output_count >= TOTAL_PIXELS) begin
                    $display("All %d expected outputs received!", TOTAL_PIXELS);
                end else begin
                    $display("No output for %d cycles - ending simulation", MAX_NO_OUTPUT_CYCLES);
                end
                
                // Close files
                $fclose(file_L_RGB);
                $fclose(file_R_RGB);
                $fclose(file_disparity);
                // $fclose(file_disp_L);
                // $fclose(file_disp_R);
                
                $display("Files closed. Simulation finished.");
                $finish;
            end
        end
    end
    
    //================= Debug Monitoring =================
    always @(posedge clkLow) begin
        if(rstn && data_transmission_active && output_pixel_index < 10) begin
            $display("Time %0t: Output Pixel %d - L_RGB=%06h, R_RGB=%06h, Valid=L:%b R:%b", 
                     $time, output_pixel_index, data_in_L_RGB, data_in_R_RGB, 
                     data_in_L_valid, data_in_R_valid);
        end
    end
    
    // Monitor first few outputs
    always @(posedge clkHigh) begin
        if(data_out_lrc_valid && output_count < 10) begin
            $display("Time %0t: Disparity Output #%d: %d", 
                     $time, output_count + 1, data_out_lrc);
        end
    end
    
    //================= Left/Right Disparity Monitoring =================
    
    // reg data_tx_ready_L_prev, data_tx_ready_R_prev;
    // wire [5:0] debug_disp_aggr_L, debug_disp_aggr_R;
    // wire debug_data_tx_ready_L, debug_data_tx_ready_R;
    // always @(posedge clkHigh or negedge rstn) begin
    //     if(!rstn) begin
    //         data_tx_ready_L_prev <= 0;
    //         data_tx_ready_R_prev <= 0;
    //     end else begin
    //         data_tx_ready_L_prev <= debug_data_tx_ready_L;
    //         data_tx_ready_R_prev <= debug_data_tx_ready_R;
            
    //         // 检测data_tx_ready_L上升沿，写入左视差
    //         if(debug_data_tx_ready_L && !data_tx_ready_L_prev && files_opened) begin
    //             $fwrite(file_disp_L, "%d\n", debug_disp_aggr_L);
    //         end
            
    //         // 检测data_tx_ready_R上升沿，写入右视差
    //         if(debug_data_tx_ready_R && !data_tx_ready_R_prev && files_opened) begin
    //             $fwrite(file_disp_R, "%d\n", debug_disp_aggr_R);
    //         end
    //     end
    // end
    
    //================= DUT Instantiation =================
    topPL_tb u_topPL_tb(
        .clk_input(clk_input),
        .locked(locked),
        .clkHigh(clkHigh),
        .clkLow(clkLow),
        .rstn(rstn),
        .data_in_L_RGB(data_in_L_RGB),
        .data_in_R_RGB(data_in_R_RGB),
        .data_in_L_valid(data_in_L_valid),
        .data_in_R_valid(data_in_R_valid),
        .data_out_lrc(data_out_lrc),
        .data_out_lrc_valid(data_out_lrc_valid)

        // .debug_disp_aggr_L(debug_disp_aggr_L),
        // .debug_disp_aggr_R(debug_disp_aggr_R),
        // .debug_data_tx_ready_L(debug_data_tx_ready_L),
        // .debug_data_tx_ready_R(debug_data_tx_ready_R)
    );
    
    //================= Simulation Timeout =================
    initial begin
        // Maximum simulation time limit (e.g., 100ms)
        #100000000;
        $display("ERROR: Simulation timeout reached!");
        $display("Total outputs received: %d", output_count);
        if(files_opened) begin
            $fclose(file_L_RGB);
            $fclose(file_R_RGB); 
            $fclose(file_disparity);
            // $fclose(file_disp_L);
            // $fclose(file_disp_R);
        end
        $finish;
    end

endmodule