`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/10/22 01:46:08
// Design Name: 
// Module Name: sysdemo_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module sysdemo_tb(

    );

    reg clkHigh;
    reg clkLow;
    reg rstn;
    reg   [23:0] data_in_L_RGB;
    reg   [23:0] data_in_R_RGB;
    reg          data_in_L_valid;
    reg          data_in_R_valid;
    wire  [7:0]  data_out_lrc;
    wire         data_out_lrc_valid;

    topPL_tb topPL_tb(
    .clkHigh(clkHigh),
    .clkLow(clkLow),
    .rstn(rstn),
    .data_in_L_RGB(data_in_L_RGB),
    .data_in_R_RGB(data_in_R_RGB),
    .data_in_L_valid(data_in_L_valid),
    .data_in_R_valid(data_in_R_valid),
    .data_out_lrc(data_out_lrc),
    .data_out_lrc_valid(data_out_lrc_valid)
    );

    
endmodule
