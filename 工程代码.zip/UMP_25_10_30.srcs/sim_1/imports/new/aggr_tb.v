`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/20 21:14:26
// Design Name: 
// Module Name: aggr_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`define MAX_DISP 64
module aggr_tb;
    reg clk;
    reg rst_n;
    reg [`MAX_DISP*5-1:0] data_in_cost;
    reg [7:0]             data_in_gray;
    reg                  data_in_valid;
    wire                    data_ready;
    wire                    data_tx_ready;
    wire [5:0]                data_out;
    integer file_cost,file_gray,file_disparity;

    always #5 clk = ~clk;
    
    initial begin
        rst_n = 0;
        clk = 0;
        # 95 rst_n = 1;
        file_cost = $fopen("depth_values.txt","r");
        file_gray = $fopen("gray_values.txt","r");
        file_disparity = $fopen("disparity.txt","w");
        if(file_cost==0||file_gray==0||file_disparity==0) begin
            $display("ERROR: Failed to open input/output files!");
            $stop;
        end
        $display("=== Simulation Started ===");
        $display("Processing pixels from (1,1) to (375,450)...");
        $display("Input files: depth_values.txt, gray_values.txt");
        $display("Output file: disparity.txt");
        $display("Total pixels to process: %d", 375*450);
        $display("========================");
    end
    
    //================= 像素数据缓存 =============
    reg [319:0] depth_string; // 64 * 5 = 320 bits for depth values
    reg [7:0] gray_string; // 8 bits for gray value
    reg [319:0] current_depth_data; // 当前像素的深度数据
    reg [7:0] current_gray_data; // 当前像素的灰度数据
    reg [319:0] next_depth_data; // 下一个像素的深度数据
    reg [7:0] next_gray_data; // 下一个像素的灰度数据
    
    reg [9:0] pixel_index; // 当前像素索引 (1-450)
    reg [9:0] row_index; // 当前行索引 (1-375)
    reg data_read_success;
    reg pixel_data_ready; // 像素数据准备就绪标志
    reg first_pixel_loaded; // 第一个像素是否已加载
    reg data_rx_ready_prev; // 上一个周期的data_rx_ready状态
    reg [9:0] next_row; // 下一个像素的行号
    reg [9:0] next_pixel; // 下一个像素的列号
    
    //================= 数据读取控制 =============
    reg [20:0] cnt;
    always@(posedge clk, negedge rst_n)begin
        if(!rst_n)begin
            pixel_index <= 1; // 从第1个像素开始
            row_index <= 1; // 从第1行开始
            current_depth_data <= 0;
            current_gray_data <= 0;
            next_depth_data <= 0;
            next_gray_data <= 0;
            data_read_success <= 1;
            pixel_data_ready <= 0;
            first_pixel_loaded <= 0;
            data_rx_ready_prev <= 0;
            next_row <= 1;
            next_pixel <= 2;
        end
        else begin
            data_rx_ready_prev <= data_ready;
            
            // 预加载第一个像素数据
            if(!first_pixel_loaded && rst_n) begin
                // 读取第一个像素的深度数据
                if($fscanf(file_cost,"Pixel(%0d,%0d):%320b", row_index, pixel_index, depth_string) == 3) begin
                    current_depth_data <= depth_string;
                    $display("Clock %d: Preloaded first depth data for pixel (%d,%d)", cnt, row_index, pixel_index);
                end else begin
                    data_read_success <= 0;
                    $display("Failed to preload first depth data");
                end
                
                // 读取第一个像素的灰度数据  
                if($fscanf(file_gray,"Pixel(%0d,%0d): %8b", row_index, pixel_index, gray_string) == 3) begin
                    current_gray_data <= gray_string;
                    $display("Clock %d: Preloaded first gray data %b for pixel (%d,%d)", cnt, gray_string, row_index, pixel_index);
                end else begin
                    data_read_success <= 0;
                    $display("Failed to preload first gray data");
                end
                
                // 预读第二个像素数据
                if($fscanf(file_cost,"Pixel(%0d,%0d):%320b", row_index, pixel_index + 1, depth_string) == 3) begin
                    next_depth_data <= depth_string;
                    $display("Clock %d: Preloaded second depth data", cnt);
                end
                
                if($fscanf(file_gray,"Pixel(%0d,%0d): %8b", row_index, pixel_index + 1, gray_string) == 3) begin
                    next_gray_data <= gray_string;
                    $display("Clock %d: Preloaded second gray data %b", cnt, gray_string);
                end
                
                first_pixel_loaded <= 1;
                pixel_data_ready <= 1;
                pixel_index <= pixel_index + 1;
            end
            
            // 检测到data_rx_ready上升沿时，更新数据缓存（模块准备接收下一个像素）
            else if(data_ready && !data_rx_ready_prev && data_read_success) begin
                // 将下一个像素数据移动到当前位置
                current_depth_data <= next_depth_data;
                current_gray_data <= next_gray_data;
                
                // 更新像素和行索引
                if(pixel_index == 450) begin
                    // 当前行结束，切换到下一行
                    if(row_index < 375) begin
                        row_index <= row_index + 1;
                        pixel_index <= 1;
                    end else begin
                        // 已经是最后一行的最后一个像素
                        pixel_index <= pixel_index + 1;
                    end
                end else begin
                    pixel_index <= pixel_index + 1;
                end
                
                // 预读下下个像素数据（除非已经是最后一个像素）
                if(!(row_index == 375 && pixel_index == 450)) begin
                    if(pixel_index == 450) begin
                        next_row <= row_index + 1;
                        next_pixel <= 1;
                    end else begin
                        next_row <= row_index;
                        next_pixel <= pixel_index + 1;
                    end
                    
                    if($fscanf(file_cost,"Pixel(%0d,%0d):%320b", next_row, next_pixel, depth_string) == 3) begin
                        next_depth_data <= depth_string;
                        $display("Clock %d: Read next depth data for pixel (%d,%d)", cnt, next_row, next_pixel);
                    end else begin
                        data_read_success <= 0;
                        $display("Failed to read depth data for pixel (%d,%d)", next_row, next_pixel);
                    end
                    
                    if($fscanf(file_gray,"Pixel(%0d,%0d): %8b", next_row, next_pixel, gray_string) == 3) begin
                        next_gray_data <= gray_string;
                        $display("Clock %d: Read next gray data %b for pixel (%d,%d)", cnt, gray_string, next_row, next_pixel);
                    end else begin
                        data_read_success <= 0;
                        $display("Failed to read gray data for pixel (%d,%d)", next_row, next_pixel);
                    end
                end
            end
        end
    end
    
    //================= data_in_valid 控制 =============
    reg data_valid_started;
    
    always@(posedge clk, negedge rst_n) begin
        if(!rst_n) begin
            data_valid_started <= 0;
        end
        else if(pixel_data_ready && data_read_success && !data_valid_started) begin
            // 第一次数据准备好时，开始拉高valid并保持
            data_valid_started <= 1;
        end
    end
    
    always@(*) begin
        if(!rst_n) begin
            data_in_valid = 0;
        end
        else if(data_valid_started && data_read_success) begin
            // 一旦开始，就一直保持拉高（除非读取失败）
            data_in_valid = 1;
        end
        else begin
            data_in_valid = 0;
        end
    end
    
    //================= 数据输出控制 =============
    // 使用组合逻辑，在ready拉高时立即切换到下一个像素数据
    always@(*) begin
        if(!rst_n) begin
            data_in_cost = 0;
            data_in_gray = 0;
        end
        else if(pixel_data_ready && data_read_success) begin
            // 组合逻辑：rx_ready拉高时立即输出下一个像素数据，否则输出当前像素数据
            if(data_ready) begin
                // rx_ready拉高：立即输出下一个像素数据
                data_in_cost = next_depth_data;
                data_in_gray = next_gray_data;
            end
            else begin
                // rx_ready未拉高：输出当前像素数据
                data_in_cost = current_depth_data;
                data_in_gray = current_gray_data;
            end
        end
        else begin
            data_in_cost = 0;
            data_in_gray = 0;
        end
    end
    
    //================= 仿真控制 =============
    reg simulation_done;
    
    always@(posedge clk, negedge rst_n)begin
       if(!rst_n)begin
        cnt <= 0;
        simulation_done <= 0;
       end
       else if(data_tx_ready == 1 && rst_n == 1)begin
        cnt <= cnt + 1;
        
        // 通过文件读取状态或达到最大像素数自动控制仿真结束
        if(!data_read_success || simulation_done || cnt >= (375*450)) begin
            // 不在这里立即结束，等待最后的视差值写入完成
            simulation_done <= 1;
        end
       end
    end
    
    // 检测是否到达文件末尾
    always@(posedge clk, negedge rst_n)begin
        if(!rst_n)begin
            simulation_done <= 0;
        end
        else if(!data_read_success)begin
            simulation_done <= 1;
            $display("Time %0t: File read failed or EOF reached", $time);
        end
    end 
    
    // 输出文件写入 - 使用非阻塞检验，在data_tx_ready有效的下一个时钟记录
    reg data_tx_ready_reg;
    reg [5:0] data_out_reg;
    reg [9:0] row_index_reg, pixel_index_reg;
    
    always@(posedge clk, negedge rst_n)begin
        if(!rst_n) begin
            data_tx_ready_reg <= 0;
            data_out_reg <= 0;
            row_index_reg <= 0;
            pixel_index_reg <= 0;
        end else begin
            // 非阻塞赋值，延迟一个时钟
            data_tx_ready_reg <= data_tx_ready;
            data_out_reg <= data_out;
            row_index_reg <= row_index;
            pixel_index_reg <= pixel_index;
        end
    end
    
    // 在data_tx_ready有效的下一个时钟写入文件
    reg [20:0] write_cnt; // 记录已写入文件的像素数
    
    always@(posedge clk, negedge rst_n)begin
        if(!rst_n) begin
            write_cnt <= 0;
        end else if(data_tx_ready_reg == 1 && rst_n == 1) begin
            $fwrite(file_disparity,"%d\n",data_out_reg);
            $display("Time %0t: Pixel (%d,%d) - disparity=%d written to file", $time, row_index_reg, pixel_index_reg, data_out_reg);
            
            write_cnt <= write_cnt + 1;
            
            // 每100个像素显示进度
            if(write_cnt % 100 == 0 && write_cnt > 0) begin
                $display("Progress: %0d pixels written to disparity.txt so far...", write_cnt + 1);
            end
            
            // 检查是否已写入所有像素的视差值
            if(write_cnt >= (375*450 - 1)) begin
                $display("=== All disparity values written to file ===");
                $display("Total pixels processed: %d", write_cnt + 1);
                $display("Closing files and finishing simulation...");
                $fclose(file_cost);
                $fclose(file_gray);
                $fclose(file_disparity);
                $finish();
            end
        end
    end
    
    // 关键信号变化监控
    always@(posedge clk) begin
        if(rst_n && data_valid_started) begin
            $display("Time %0t: TIMING CHECK - valid=%b, tx_ready=%b, cost=%h, gray=%h, pixel=(%d,%d)", 
                     $time, data_in_valid, data_tx_ready, data_in_cost, data_in_gray, row_index, pixel_index);
            // 显示当前使用的是哪个数据缓存
            if(data_tx_ready) begin
                $display("  -> Using NEXT pixel data (tx_ready=1)");
            end else begin
                $display("  -> Using CURRENT pixel data (tx_ready=0)");
            end
        end
    end

    aggregation u_cell(
      .clk(clk),
      .rst_n(rst_n),
      .data_in_cost(data_in_cost),//输入代价数据
      .data_in_gray(data_in_gray),//输入灰度数据
      .data_in_valid(data_in_valid),
      .data_rx_ready(data_ready),
      .disp_aggr(data_out),
      .data_tx_ready(data_tx_ready)
      );
    
    
endmodule