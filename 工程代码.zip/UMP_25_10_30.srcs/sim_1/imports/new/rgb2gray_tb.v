`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/17 14:06:48
// Design Name: 
// Module Name: rgb2gray_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module rgb2gray_tb(
    );
    reg clk;
    reg rstn;
    reg   [23:0] data_in;
    reg          data_in_valid;
    
    wire  [7:0]    data_out;
    wire     data_out_valid;
    
    always #5 clk = ~clk;
    initial begin
        rstn = 0;
        clk = 0;
        # 50 rstn = 1;
    end
    always@(posedge clk, negedge rstn)begin
        if(!rstn)begin
            data_in_valid <= 0;
        end
        else begin
            data_in_valid <= 1;
        end
    end
    always@(posedge clk, negedge rstn)begin
        if(!rstn)begin
            data_in <= 24'h01_11_11;
        end
//        else begin
        else if(data_in_valid)begin
            data_in <= data_in + 1'b1;
        end
    end
    
    
    
    rgb2gray u_cell(
       .clk(clk),
       .rstn(rstn),
    
       .data_in(data_in),
       .data_in_valid(data_in_valid),
    
       .data_out(data_out),
       .data_out_valid(data_out_valid)
    );
endmodule
