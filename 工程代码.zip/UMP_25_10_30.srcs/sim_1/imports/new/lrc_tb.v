`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/30 14:25:39
// Design Name: 
// Module Name: lrc_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module lrc_tb();
    //-- DUT Signals --
    reg clk;
    reg rst_n;
    
    reg [7:0] disp_aggr_in_L;
    reg [7:0] disp_aggr_in_R;
    
    reg       disp_aggr_in_L_valid;
    reg       disp_aggr_in_R_valid;
    
    wire [5:0] data_lrc_out;
    wire       data_lrc_out_valid;

    //-- Testbench Internal Signals --
    integer file_L, file_R, file_out;
    integer read_status_L, read_status_R;
    reg     sim_start;

    //-- Clock Generation --
    always #5 clk = ~clk;

    //-- Initialization and Reset --
    initial begin
        clk = 0;
        rst_n = 0;
        disp_aggr_in_L = 0;
        disp_aggr_in_R = 0;
        disp_aggr_in_L_valid = 0;
        disp_aggr_in_R_valid = 0;
        sim_start = 0;

        // Open files
        file_L = $fopen("disp_aggr_L_binary.txt", "r");
        file_R = $fopen("disp_aggr_R_binary.txt", "r");
        file_out = $fopen("lrc.txt", "w");

        if (file_L == 0 || file_R == 0 || file_out == 0) begin
            $display("ERROR: Failed to open input/output files!");
            $stop;
        end

        $display("=== LRC Simulation Started ===");
        $display("Input files: disp_aggr_L.txt, disp_aggr_R.txt");
        $display("Output file: lrc.txt");
        $display("==============================");

        // Apply reset
        #95;
        rst_n = 1;
        #10; // Wait one clock cycle after reset
        sim_start = 1; // Signal to start data feed
    end

    //-- Data Input Control --
    always @(posedge clk, negedge rst_n) begin
        if (!rst_n) begin
            disp_aggr_in_L_valid <= 0;
            disp_aggr_in_R_valid <= 0;
            disp_aggr_in_L <= 8'd0;
            disp_aggr_in_R <= 8'd0;
        end 
        else if (sim_start) begin
            // Pull valids high and start reading
            disp_aggr_in_L_valid <= 1;
            disp_aggr_in_R_valid <= 1;

            // Read from files on each clock cycle
            read_status_L = $fscanf(file_L, "%b\n", disp_aggr_in_L);
            read_status_R = $fscanf(file_R, "%b\n", disp_aggr_in_R);
            if (read_status_L == 1 && read_status_R == 1) begin
                disp_aggr_in_L_valid <= 1;
                disp_aggr_in_R_valid <= 1;
            end
            // Check for end of file
            else begin
                $display("Time %0t: End of input file reached.", $time);
                disp_aggr_in_L_valid <= 0; // Stop feeding data
                disp_aggr_in_R_valid <= 0;
            end
        end
    end

    //-- Data Output Handling --
    always @(posedge clk) begin
        if (rst_n && data_lrc_out_valid) begin
            $fwrite(file_out, "%d\n", data_lrc_out);
            $display("Time %0t: Output valid. Wrote disparity %b to lrc.txt", $time, data_lrc_out);
        end
    end
    
      //-- Simulation Termination --
    reg [31:0] output_count;
    always @(posedge clk, negedge rst_n) begin  // 添加复位敏感信号
        if (!rst_n) begin
            output_count <= 32'd0;  // 复位时清�??
        end
        else if(data_lrc_out_valid == 1'b0 && output_count == 32'd168750) begin
             $display("=== Simulation Finished ===");
             $display("Total disparity values written: %d", output_count);
             $fclose(file_L);
             $fclose(file_R);
             $fclose(file_out);
             $stop;
        end
        else if (data_lrc_out_valid == 1'b1 && rst_n == 1'b1) begin  // �??化条件，rst_n已经在复位条件中�??�??
            output_count <= output_count + 1;
        end
    end
    

    //-- Instantiate DUT --
    lrc u_cell(
        .clk                  (clk),
        .rst_n                (rst_n),
        .disp_aggr_in_L       (disp_aggr_in_L),
        .disp_aggr_in_R       (disp_aggr_in_R),
        .disp_aggr_in_L_valid (disp_aggr_in_L_valid),
        .disp_aggr_in_R_valid (disp_aggr_in_R_valid),
        .data_lrc_out         (data_lrc_out),
        .data_lrc_out_valid   (data_lrc_out_valid)
    );
endmodule
