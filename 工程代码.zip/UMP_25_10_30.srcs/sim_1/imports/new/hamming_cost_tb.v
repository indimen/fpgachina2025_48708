`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/17 14:06:48
// Design Name: 
// Module Name: rgb2gray_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`define MAX_DISP 64
module hamming_cost_tb(
    );
    reg clk;
    reg rstn;
      
    reg   [24:0] data_in_L;
    reg   [24:0] data_in_R;
    reg          data_in_L_valid;
    reg          data_in_R_valid;
    
    wire  [`MAX_DISP*5-1:0] data_out;//cost space 
    wire              data_out_valid;
    
    always #5 clk = ~clk;
    
    initial begin
        rstn = 0;
        clk = 0;
        # 95 rstn = 1;
    end
    
    always@(posedge clk, negedge rstn)begin
        if(!rstn)begin
            data_in_L_valid <= 0;
            data_in_R_valid <= 0;
        end
        else begin
            data_in_L_valid <= 1;
            data_in_R_valid <= 1;
        end
    end
        
    always@(posedge clk, negedge rstn)begin
        if(!rstn)begin
            data_in_L <= 25'h1f0f0f0;
        end
//        else begin
        else if(data_in_L_valid)begin
            data_in_L <= data_in_L + 1'b1;
        end
    end
    
    always@(posedge clk, negedge rstn)begin
        if(!rstn)begin
            data_in_R <= 25'b0;
        end
//        else begin
        else if(data_in_R_valid)begin
            data_in_R <= data_in_R + 1'b1;
        end
    end
    
    
    hamming_cost u_cell(
     .clk(clk),
     .rst_n(rstn),
     .data_in_L(data_in_L),
     .data_in_R(data_in_R),
     .data_in_L_valid(data_in_L_valid),
     .data_in_R_valid(data_in_R_valid),
    
     .data_out(data_out),//cost space 
     .data_out_valid(data_out_valid)
    
    );

endmodule
