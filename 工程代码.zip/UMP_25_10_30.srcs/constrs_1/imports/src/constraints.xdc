########################################
# - clkLow (15 MHz)
# - clkHigh (150 MHz)
########################################

# clk_pl_0 = 15 MHz 
# clk_pl_1 = 150 MHz
set_clock_groups -asynchronous \
    -group [get_clocks -include_generated_clocks clk_pl_1] \
    -group [get_clocks -include_generated_clocks clk_pl_0]
