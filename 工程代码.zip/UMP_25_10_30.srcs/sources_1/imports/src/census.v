`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////

//640x480
`define H 375
`define W 450
module census( //5x5 window size
    input   clk,
    input   rst_n,
    
    input   [7:0]   data_in,          //8 bit stream from gray image
    input           data_in_valid,    //valid signal from gray image
    
    output  [24:0]  data_out,         //25 bit census vector
    output   reg    data_out_valid    //valid signal from census vector
    );
    //======================== postion counter ===============
    reg [9:0] col_pos;
    reg [9:0] row_pos;
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)
            col_pos <= 0;
        else if( col_pos == `W-1 && data_out_valid ==1'b1)
            col_pos <= 0;
        else if(data_out_valid == 1'b1)
            col_pos <= col_pos + 1'b1;
    end
    
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)
            row_pos <= 0;
        else if( row_pos == `H-1 && col_pos == `W-1 && data_out_valid ==1'b1)
            row_pos <= 0;
        else if(data_out_valid == 1'b1 && col_pos == `W-1)
            row_pos <= row_pos + 1'b1;
    end
    //======================= index for linebuffer ==================
    reg [9 : 0] write_index;
    reg [9 : 0] read_index ;
    always@(posedge clk,negedge rst_n)begin
        if(~rst_n)begin
            write_index<=0;
            read_index<=0;
        end
        else if(data_in_valid==1'b1)begin
            //========== write_index ==========
            if(write_index == `W-1)
                write_index <= 0;
            else
                write_index <= write_index + 1'b1;
            //========= read_index ===========
            if(write_index >= `W-2)  // 当addra >= W-2时，addra+2会超过W-1
                read_index <= write_index + 2 - `W;
            else
                read_index <= write_index + 2;
        end
    end
    
    //=========== linebuffer ==============
    wire [7:0] linebuffer_in[0:4];
    wire [7:0] linebuffer_out[0:4];
    
    assign linebuffer_in[0] = data_in;
    genvar k ;
    generate 
        for (k=1;k<5;k=k+1)begin
            assign linebuffer_in[k] = linebuffer_out[k-1];
        end
    endgenerate
    
    generate //dual port RAM at the same time, write new pixel data in port A and read old pixel data from port B
         for (k=0;k<5;k=k+1)begin
            linebuffer your_instance_name ( //dual port RAM
              .clka(clk),                 // input wire clka
              .ena(data_in_valid),        // port A enable
              .wea(data_in_valid),        // port A write enable
              .addra(write_index),              // port A address
              .dina(linebuffer_in[k]),    // port A data input
              
              .clkb(clk),                // port B clock
              .enb(data_in_valid),       // port B enable
              .addrb(read_index),             // port B address
              .doutb(linebuffer_out[k])  // port B data output
            );
        end
    endgenerate
    
    //=============== get window====================================
    reg [7:0] window [4:0][4:0];
    integer i,j;
    always@(posedge clk,negedge rst_n)begin
        if(~rst_n)begin
            for(i=0;i<5;i=i+1)begin
                for(j=0;j<5;j=j+1)begin
                     window[i][j]<=0;
                end
            end
        end
        else begin
            for(i=0;i<5;i=i+1)begin
                window[i][0]<=linebuffer_in[i];
                for(j=1;j<5;j=j+1)begin
                     window[i][j]<=window[i][j-1];
                end
            end
        end
    end
    //====================== Census ==========================
    wire [7:0] center;
    reg [24:0] census_vec;
    //============= window_valid ==========================
    wire window_valid = ((row_pos >= 4) && (col_pos >= 4)) ? 1'b1 : 1'b0;

    assign center = window[2][2];
    genvar x,y;
    generate
        for(y=0;y<5;y=y+1)begin
            for(x=0;x<5;x=x+1)begin
                always@(posedge clk ,negedge rst_n)begin
                    if(~rst_n)begin
                        census_vec[y*5+x] <= 0;
                    end
                    else begin
                        if(window[y][x] > center )
                            census_vec[y*5+x] <= 1'b1;
                        else
                            census_vec[y*5+x] <= 1'b0;
                    end
                end
            end 
        end
    endgenerate
    
    assign data_out = window_valid ? census_vec : 25'b0;
    //============= data_valid delay 2 cycles ==========================
    //get_window + Census = 2 cycles
    reg delay_data_in_valid;
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)begin
            delay_data_in_valid <= 0;
            data_out_valid <= 0;
        end
        else begin
            delay_data_in_valid <= data_in_valid;
            data_out_valid <= delay_data_in_valid;
        end
    end
    
endmodule
