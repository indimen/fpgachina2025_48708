`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
`define MAX_DISP 64
`define T 16
module lrc(
    input   clk,
    input   rst_n,
    
    input   [5:0]   disp_aggr_in_L,
    input   [5:0]   disp_aggr_in_R,
    
    input           disp_aggr_in_L_valid,
    input           disp_aggr_in_R_valid,
    
    
    output  [5:0]   data_lrc_out,
    output   reg    data_lrc_out_valid
    );
//=================== ���ݻ��� ��λ�Ĵ�===========================
    reg [5:0]   disparity_buffer[0:`MAX_DISP-1];
    integer i;
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)begin
            for(i=0;i<`MAX_DISP;i=i+1)begin
                disparity_buffer[i]<=0;
            end
        end
        else begin
            if(disp_aggr_in_R_valid == 1'b1)begin
                disparity_buffer[0] <= disp_aggr_in_R;
                for(i=1;i<`MAX_DISP;i=i+1)begin
                    disparity_buffer[i]<=disparity_buffer[i-1];
                end
            end
        end
    end
    
    wire [5:0] corr_disp;
    reg  [5:0] data_out_reg;
    assign corr_disp = (disp_aggr_in_L == 0) ? 6'd0 : 
                       (disp_aggr_in_L <= `MAX_DISP) ? disparity_buffer[disp_aggr_in_L - 1] : 6'd0;
    
    //=================== ���Ƚ� ============================
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)begin
            data_out_reg <= 0;
        end
        else begin
            if(disp_aggr_in_L_valid == 1'b1)begin
            if(corr_disp>=disp_aggr_in_L)begin
                    if(corr_disp - disp_aggr_in_L < `T)
                        data_out_reg <= disp_aggr_in_L;
                    else
                        data_out_reg <= 0;
            end
            else begin
                    if(disp_aggr_in_L -  corr_disp < `T)
                        data_out_reg <= disp_aggr_in_L;
                    else
                        data_out_reg <= 0;
            end
            end
        end
    end
    
    //=================================
    assign data_lrc_out = data_out_reg;
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)begin
            data_lrc_out_valid <= 0;
        end
        else begin
            data_lrc_out_valid <= disp_aggr_in_L_valid;
        end
    end

    // assign data_lrc_out = (disp_aggr_in_L_valid == 1'b1) ?
    //                     ( ( (corr_disp >= disp_aggr_in_L) && (corr_disp - disp_aggr_in_L < `T) ) ||
    //                     ( (corr_disp <  disp_aggr_in_L) && (disp_aggr_in_L - corr_disp < `T) ) ) ?
    //                     disp_aggr_in_L : 8'd0
    //                     : 8'd0; // ��validΪ0ʱ������ԭֵ

endmodule
