`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/10/01 23:02:32
// Design Name: 
// Module Name: topPL
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`define MAX_DISP 64
`define HAMMING_DELAY (70-7)
`define Width 450
`define Height 375
module topPL_tb();
    /*-----------PL interface-----------*/
    wire                          clkHigh;
    wire                           clkLow;
    wire                             rstn;
    wire   [23:0]           data_in_L_RGB;
    wire   [23:0]           data_in_R_RGB;
    wire                  data_in_L_valid;
    wire                  data_in_R_valid;
    wire   [7:0]        data_out_lrc_sync;
    wire          data_out_lrc_valid_sync;
    /*--------------------------------------------*/
    /*bdDesign wrapper PS - DMA - PL; PS interface*/
    wire [63:0]   M_AXIS_MM2S_tdata; //output
    wire          M_AXIS_MM2S_tlast; 
    wire          M_AXIS_MM2S_tready;
    wire          M_AXIS_MM2S_tvalid;
    wire [31:0]   S_AXIS_S2MM_tdata;
    wire [3:0]    S_AXIS_S2MM_tkeep;
    wire          S_AXIS_S2MM_tlast;
    wire          S_AXIS_S2MM_tready;
    wire          S_AXIS_S2MM_tvalid;

    /*  output [63:0]M_AXIS_MM2S_tdata;
        output [7:0]M_AXIS_MM2S_tkeep;
        output M_AXIS_MM2S_tlast;
        input M_AXIS_MM2S_tready;
        output M_AXIS_MM2S_tvalid;
        input [31:0]S_AXIS_S2MM_tdata;
        input [3:0]S_AXIS_S2MM_tkeep;
        input S_AXIS_S2MM_tlast;
        output S_AXIS_S2MM_tready;
        input S_AXIS_S2MM_tvalid;
        output pl_clkHigh;
        output pl_clkLow;
        output pl_rstn;
    */
    
    /*bdDesign wrapper instance*/
    bdDesign_wrapper u_bdDesign_wrapper
    (.M_AXIS_MM2S_tdata(M_AXIS_MM2S_tdata),
     .M_AXIS_MM2S_tlast(M_AXIS_MM2S_tlast),
     .M_AXIS_MM2S_tready(M_AXIS_MM2S_tready),
     .M_AXIS_MM2S_tvalid(M_AXIS_MM2S_tvalid),
    /*-----------------------------------------*/
     .S_AXIS_S2MM_tdata(S_AXIS_S2MM_tdata),
     .S_AXIS_S2MM_tkeep(S_AXIS_S2MM_tkeep),
     .S_AXIS_S2MM_tlast(S_AXIS_S2MM_tlast),
     .S_AXIS_S2MM_tready(S_AXIS_S2MM_tready),
     .S_AXIS_S2MM_tvalid(S_AXIS_S2MM_tvalid),
    /*-----------------------------------------*/
     .pl_clkHigh(clkHigh),
     .pl_clkLow(clkLow),
     .pl_rstn(rstn));

    assign M_AXIS_MM2S_tready =                              1;
    assign S_AXIS_S2MM_tdata = {26'b0, data_out_lrc_sync[5:0]};
    assign S_AXIS_S2MM_tkeep =                            4'hF;

    // Tlast信号：帧结束标志
    // 需要一个计数器来检测一帧的最后一个像素
    reg [23:0] pixel_count;  
    wire is_last_pixel = (pixel_count == `Width*`Height-1) && S_AXIS_S2MM_tvalid;
    
    assign S_AXIS_S2MM_tlast = is_last_pixel;
    
    always @(posedge clkLow, negedge rstn) begin
        if (~rstn) begin
            pixel_count <= 24'd0;
        end 
        else begin
            if (S_AXIS_S2MM_tvalid && S_AXIS_S2MM_tready) begin
                if (is_last_pixel)
                    pixel_count <= 24'd0;
                else
                    pixel_count <= pixel_count + 1'b1;
            end
        end
    end

    assign S_AXIS_S2MM_tvalid = data_out_lrc_valid_sync;
    /*--------------------------------------------*/
    /*DMA to PL FIFO*/
    wire [47:0] FIFO_DMA2PL_din = {M_AXIS_MM2S_tdata[55:32], M_AXIS_MM2S_tdata[23:0]};
    wire [47:0]                                                      FIFO_DMA2PL_dout;
   
    wire                                                             FIFO_DMA2PL_full;
    wire                                                            FIFO_DMA2PL_empty;

    FIFO_DMA2PL u_FIFO_DMA2PL(  
        .clk(clkLow),
        .srst(~rstn),
        .din(FIFO_DMA2PL_din),
        .wr_en(M_AXIS_MM2S_tvalid && M_AXIS_MM2S_tready),
        .rd_en(~FIFO_DMA2PL_empty),
        .dout(FIFO_DMA2PL_dout),
        .full(FIFO_DMA2PL_full),
        .empty(FIFO_DMA2PL_empty));

    assign data_in_L_RGB = FIFO_DMA2PL_dout [47:24];
    assign data_in_R_RGB = FIFO_DMA2PL_dout [23: 0];
    assign data_in_L_valid = ~FIFO_DMA2PL_empty;
    assign data_in_R_valid = ~FIFO_DMA2PL_empty;
    
    /*===================================================*/
    /*-----------------Original Logic--------------------*/
    wire data_rx_ready_L, data_rx_ready_R;

    wire    [7:0]  data_out_L_gray;
    wire    [7:0]  data_out_R_gray;
    wire           data_out_L_gray_valid;
    wire           data_out_R_gray_valid;
    //2 cycles delay
    rgb2gray u_rgb2gray_L(
    .clk(clkLow),
    .rstn(rstn),
    .data_in(data_in_L_RGB),
    .data_in_valid(data_in_L_valid),
    .data_out(data_out_L_gray),
    .data_out_valid(data_out_L_gray_valid)
    ); 
    
    // 灰度数据延迟FIFO信号定义
    wire data_out_L_gray_full;
    wire data_out_L_gray_empty;
    wire data_out_L_gray_prog_empty;
    wire [7:0] data_out_L_gray_delayed;
    reg data_out_L_gray_prog_empty_reg;
    reg data_out_L_gray_rd_en;

    // 灰度数据延迟FIFO例化
    FIFO_gray u_FIFO_gray_L(
        .clk(clkLow),                           // 时钟
        .srst(~rstn),                           // 同步复位（低有效转高有效）
        
        // 写端口
        .din(data_out_L_gray),                  // 8-bit灰度输入
        .wr_en(data_out_L_gray_valid),          // 写使能
        
        // 读端口
        .dout(data_out_L_gray_delayed),         // 8-bit延迟后的灰度输出
        .rd_en(data_out_L_gray_rd_en),    // 读使能：当FIFO数据≥阈值时读
        
        //可选
        .empty(data_out_L_gray_empty),          // 空标志（可选监控）
        .full(data_out_L_gray_full),            // 满标志（可选监控）
        
        // 可编程空标志（核心控制信号）
        .prog_empty(data_out_L_gray_prog_empty) // 当FIFO中数据<72时为1，≥72时为0
    );

    always @(posedge clkLow ,negedge rstn) begin
        if(~rstn)begin
            data_out_L_gray_prog_empty_reg <= 1;
            data_out_L_gray_rd_en <= 0;
        end
        else begin
            data_out_L_gray_prog_empty_reg <= data_out_L_gray_prog_empty;
            if(data_out_L_gray_prog_empty_reg && ~data_out_L_gray_prog_empty)begin
                data_out_L_gray_rd_en <= 1;
            end
            else if(data_out_L_gray_empty)begin
                data_out_L_gray_rd_en <= 0;
            end
        end
    end

    // 延迟后的valid信号
    wire data_out_L_gray_delayed_valid = data_out_L_gray_rd_en && ~data_out_L_gray_empty;
    
    //2 cycles delay
    rgb2gray u_rgb2gray_R(
    .clk(clkLow),
    .rstn(rstn),
    .data_in(data_in_R_RGB),
    .data_in_valid(data_in_R_valid),
    .data_out(data_out_R_gray),
    .data_out_valid(data_out_R_gray_valid)
    );

    // 右侧灰度数据延迟FIFO信号定义
    wire data_out_R_gray_full;
    wire data_out_R_gray_empty;
    wire data_out_R_gray_prog_empty;
    wire [7:0] data_out_R_gray_delayed;
    reg data_out_R_gray_prog_empty_reg;
    reg data_out_R_gray_rd_en;
    
    // 右侧灰度数据延迟FIFO例化
    // FIFO配置：FWFT模式，深度128，宽度8bit，Programmable Empty阈值72
    FIFO_gray u_FIFO_gray_R(
        .clk(clkLow),                           // 时钟
        .srst(~rstn),                           // 同步复位（低有效转高有效）
        
        // 写端口
        .din(data_out_R_gray),                  // 8-bit灰度输入
        .wr_en(data_out_R_gray_valid),          // 写使能
         
        // 读端口
        .dout(data_out_R_gray_delayed),         // 8-bit延迟后的灰度输出
        .rd_en(data_out_R_gray_rd_en),    // 读使能：当FIFO数据≥阈值时读
        
        //可选
        .empty(data_out_R_gray_empty),          // 空标志（可选监控）
        .full(data_out_R_gray_full),            // 满标志（可选监控）
        
        // 可编程空标志（核心控制信号）
        .prog_empty(data_out_R_gray_prog_empty) // 当FIFO中数据<72时为1，≥72时为0
    );
    
    always @(posedge clkLow ,negedge rstn) begin
        if(~rstn)begin
            data_out_R_gray_prog_empty_reg <= 1;
            data_out_R_gray_rd_en <= 0;
        end
        else begin
            data_out_R_gray_prog_empty_reg <= data_out_R_gray_prog_empty;
            if(data_out_R_gray_prog_empty_reg && ~data_out_R_gray_prog_empty)begin
                data_out_R_gray_rd_en <= 1;
            end
            else if(data_out_R_gray_empty)begin
                data_out_R_gray_rd_en <= 0;
            end
        end
    end

    // 延迟后的valid信号
    wire data_out_R_gray_delayed_valid = data_out_R_gray_rd_en && ~data_out_R_gray_empty;

    wire [24:0]    data_out_L_census;
    wire [24:0]    data_out_R_census;
    wire           data_out_L_census_valid;
    wire           data_out_R_census_valid;
    //2 cycles delay
    census u_census_L(
    .clk(clkLow),
    .rst_n(rstn),
    .data_in(data_out_L_gray),
    .data_in_valid(data_out_L_gray_valid),
    .data_out(data_out_L_census),
    .data_out_valid(data_out_L_census_valid)
    );
    //2 cycles delay
    census u_census_R(
    .clk(clkLow),
    .rst_n(rstn),
    .data_in(data_out_R_gray),
    .data_in_valid(data_out_R_gray_valid),
    .data_out(data_out_R_census),
    .data_out_valid(data_out_R_census_valid)
    );
    //fast pipeline
    wire [`MAX_DISP*5-1:0] data_out_L_hamming_cost;
    wire                   data_out_L_hamming_cost_valid;
    //7 cycles delay
    hamming_cost u_hamming_cost_L(//base on left census vector
    .clk(clkLow),
    .rst_n(rstn),
    .data_in_L(data_out_L_census),
    .data_in_R(data_out_R_census),
    .data_in_L_valid(data_out_L_census_valid),
    .data_in_R_valid(data_out_R_census_valid),
    .data_out(data_out_L_hamming_cost),
    .data_out_valid(data_out_L_hamming_cost_valid)
    );

    //slow pipeline
    wire [`MAX_DISP*5-1:0] data_out_R_hamming_cost;
    wire                   data_out_R_hamming_cost_valid;
    //70 cycles delay
    hamming_cost_reverse u_hamming_cost_R(//base on right census vector
    .clk(clkLow),
    .rst_n(rstn),
    .data_in_L(data_out_L_census),
    .data_in_R(data_out_R_census),
    .data_in_L_valid(data_out_L_census_valid),
    .data_in_R_valid(data_out_R_census_valid),
    .data_out(data_out_R_hamming_cost),
    .data_out_valid(data_out_R_hamming_cost_valid)
    );
    
    // 使用FIFO IP核实现代价数据延迟对齐（63个周期）
    // 相比寄存器流水线，FIFO使用Block RAM可以节省大量寄存器资源
    wire cost_L_delay_full;
    wire cost_L_delay_empty;
    wire cost_L_delay_prog_empty;
    wire [`MAX_DISP*5-1:0] aligned_cost_L;
    wire                   aligned_cost_L_valid;
    reg cost_L_delay_prog_empty_reg;
    reg cost_L_delay_rd_en;
    
    // 左侧代价延迟FIFO例化
    // FIFO配置：FWFT模式，深度128，宽度320bit，Programmable Empty阈值为HAMMING_DELAY+1（64）
    // 阈值设为64意味着当FIFO中数据≥64时prog_empty变为0，开始读取，实现63周期延迟
    FIFO_cost_delay u_FIFO_cost_L_delay(
        .clk(clkLow),                               // 时钟
        .srst(~rstn),                               // 同步复位（低有效转高有效）
        
        // 写端口 - 接收左侧hamming_cost输出
        .din(data_out_L_hamming_cost),              // 320-bit代价向量输入
        .wr_en(data_out_L_hamming_cost_valid),      // 写使能
        
        // 读端口 - 延迟后输出
        .dout(aligned_cost_L),                      // 320-bit延迟后的代价输出
        .rd_en(cost_L_delay_rd_en),           // 读使能：当FIFO数据≥阈值时读
        
        //可选
        .full(cost_L_delay_full),                   // 满标志（可选监控）
        .empty(cost_L_delay_empty),                 // 空标志（可选监控）
        
        // 可编程空标志（核心控制信号）
        .prog_empty(cost_L_delay_prog_empty)        
    );
    always @(posedge clkLow ,negedge rstn) begin
        if(~rstn)begin
            cost_L_delay_prog_empty_reg <= 1;
            cost_L_delay_rd_en <= 0;
        end
        else begin
            cost_L_delay_prog_empty_reg <= cost_L_delay_prog_empty;
            if(cost_L_delay_prog_empty_reg && ~cost_L_delay_prog_empty)begin
                cost_L_delay_rd_en <= 1;
            end
            else if(cost_L_delay_empty)begin
                cost_L_delay_rd_en <= 0;
            end
        end
    end
    // 延迟后的valid信号
    assign aligned_cost_L_valid = cost_L_delay_rd_en && ~cost_L_delay_empty;
    
    // 左侧代价异步FIFO信号定义（低速时钟域 -> 高速时钟域）
    wire cost_L_full, cost_L_empty;
    wire cost_L_wr_rst_busy, cost_L_rd_rst_busy;
    wire [`MAX_DISP*5-1:0] cost_L_out;
    //wire cost_L_out_valid;
    
    FIFO_cost u_cost_L (
      .rst(~rstn),                          // input wire rst
      .wr_clk(clkLow),                      // input wire wr_clk - 写时钟（低速）
      .rd_clk(clkHigh),                     // input wire rd_clk - 读时钟（高速）
      .din(aligned_cost_L),                 // input wire [319 : 0] din - 左侧对齐后的代价
      .wr_en(aligned_cost_L_valid),         // input wire wr_en - 写使能
      .rd_en(data_rx_ready_L),                // input wire rd_en - 读使能（FIFO非空时读）
      .dout(cost_L_out),                    // output wire [319 : 0] dout - 输出到高速时钟域
      //可选
      .full(cost_L_full),                   // output wire full
      .empty(cost_L_empty),                 // output wire empty
      .wr_rst_busy(cost_L_wr_rst_busy),     // output wire wr_rst_busy
      .rd_rst_busy(cost_L_rd_rst_busy)      // output wire rd_rst_busy
    );
    
    // 右侧代价异步FIFO信号定义（低速时钟域 -> 高速时钟域）
    wire cost_R_full, cost_R_empty;
    wire cost_R_wr_rst_busy, cost_R_rd_rst_busy;
    wire [`MAX_DISP*5-1:0] cost_R_out;
    
    FIFO_cost u_cost_R (
      .rst(~rstn),                          // input wire rst
      .wr_clk(clkLow),                      // input wire wr_clk - 写时钟（低速）
      .rd_clk(clkHigh),                     // input wire rd_clk - 读时钟（高速）
      .din(data_out_R_hamming_cost),        // input wire [319 : 0] din - 右侧代价
      .wr_en(data_out_R_hamming_cost_valid),// input wire wr_en - 写使能
      .rd_en(data_rx_ready_R),                // input wire rd_en - 读使能（FIFO非空时读）
      .dout(cost_R_out),                    // output wire [319 : 0] dout - 输出到高速时钟域
      //可选
      .full(cost_R_full),                   // output wire full
      .empty(cost_R_empty),                 // output wire empty
      .wr_rst_busy(cost_R_wr_rst_busy),     // output wire wr_rst_busy
      .rd_rst_busy(cost_R_rd_rst_busy)      // output wire rd_rst_busy
    );
    

    // 左侧灰度数据异步FIFO信号定义（低速时钟域 -> 高速时钟域）
    // 注意：FIFO_gray_async应该是8位宽的异步FIFO，与FIFO_cost类似配置
    wire gray_L_full, gray_L_empty;
    wire gray_L_wr_rst_busy, gray_L_rd_rst_busy;
    wire [7:0] gray_L_out;
    
    clock_FIFO_gray u_clock_FIFO_gray_L(
        .rst(~rstn),                            // 复位
        .wr_clk(clkLow),                        // 写时钟（低速）
        .rd_clk(clkHigh),                       // 读时钟（高速）
        
        // 写端口 - 来自低速域延迟后的灰度数据
        .din(data_out_L_gray_delayed),          // 8-bit灰度输入
        .wr_en(data_out_L_gray_delayed_valid),  // 写使能
        
        // 读端口 - 输出到aggregation模块（高速时钟域）
        .dout(gray_L_out),                      // 8-bit灰度输出
        .rd_en(data_rx_ready_L),                  // 读使能（FIFO非空时读）
        
        //可选
        .empty(gray_L_empty),                   // 空标志
        .full(gray_L_full),                     // 满标志
        .wr_rst_busy(gray_L_wr_rst_busy),
        .rd_rst_busy(gray_L_rd_rst_busy)
    );
    

    // 右侧灰度数据异步FIFO信号定义（低速时钟域 -> 高速时钟域）
    wire gray_R_full, gray_R_empty;
    wire gray_R_wr_rst_busy, gray_R_rd_rst_busy;
    wire [7:0] gray_R_out;
    
    clock_FIFO_gray u_clock_FIFO_gray_R(
        .rst(~rstn),                            // 复位
        .wr_clk(clkLow),                        // 写时钟（低速）
        .rd_clk(clkHigh),                       // 读时钟（高速）
        
        // 写端口 - 来自低速域延迟后的灰度数据
        .din(data_out_R_gray_delayed),          // 8-bit灰度输入
        .wr_en(data_out_R_gray_delayed_valid),  // 写使能
        
        // 读端口 - 输出到aggregation模块（高速时钟域）
        .dout(gray_R_out),                      // 8-bit灰度输出
        .rd_en(data_rx_ready_R),                  // 读使能（FIFO非空时读）
        
        //可选
        .empty(gray_R_empty),                   // 空标志
        .full(gray_R_full),                     // 满标志
        .wr_rst_busy(gray_R_wr_rst_busy),
        .rd_rst_busy(gray_R_rd_rst_busy)
    );
    
   
    // 定义aggregation输出信号
    
    wire [5:0] disp_aggr_L, disp_aggr_R;
    wire data_tx_ready_L, data_tx_ready_R;
    
   // 左侧聚合模块（高速时钟域）
    aggregation #(
        .IS_LEFT(1)
    ) u_aggregation_L(
        .clk(clkHigh),
        .rst_n(rstn),
        .data_in_cost(cost_L_out),               // 来自异步FIFO的代价数据
        .data_in_gray(gray_L_out),               // 来自异步FIFO的灰度数据
        .data_in_valid(~cost_L_empty),        // 代价数据有效信号
        .data_rx_ready(data_rx_ready_L),         // 左侧独立信号
        .disp_aggr(disp_aggr_L),                 // 左侧视差输出
        .data_tx_ready(data_tx_ready_L)          // 左侧就绪信号
    );

    // 右侧聚合模块（高速时钟域）
    aggregation #(
        .IS_LEFT(0)
    ) u_aggregation_R(
        .clk(clkHigh),
        .rst_n(rstn),
        .data_in_cost(cost_R_out),               // 来自异步FIFO的代价数据
        .data_in_gray(gray_R_out),               // 来自异步FIFO的灰度数据
        .data_in_valid(~cost_R_empty),        // 代价数据有效信号
        .data_rx_ready(data_rx_ready_R),         // 右侧独立信号
        .disp_aggr(disp_aggr_R),                 // 右侧视差输出
        .data_tx_ready(data_tx_ready_R)          // 右侧就绪信号
    );
    // LRC模块输出信号定义
    wire [5:0] data_lrc_out;
    wire data_lrc_out_valid;
    
    lrc u_lrc(
        .clk(clkHigh),
        .rst_n(rstn),
        .disp_aggr_in_L(disp_aggr_L),
        .disp_aggr_in_R(disp_aggr_R),
        .disp_aggr_in_L_valid(data_tx_ready_L),
        .disp_aggr_in_R_valid(data_tx_ready_R),
        .data_lrc_out(data_lrc_out),
        .data_lrc_out_valid(data_lrc_out_valid)
    );
    /*-----------------Original Logic--------------------*/
    /*===================================================*/
   
    // 连接到顶层输出端口
    wire [7:0]                         data_out_lrc_wr;
    wire                         data_out_lrc_wr_valid;
    assign data_out_lrc_wr = {2'b0, data_lrc_out[5:0]};
    assign  data_out_lrc_wr_valid = data_lrc_out_valid;

    wire                                   data_out_lrc_full;
    wire                                  data_out_lrc_empty;
    wire                            data_out_lrc_wr_rst_busy;
    wire                            data_out_lrc_rd_rst_busy;

    FIFO_lrc u_FIFO_lrc(
      .rst(~rstn),                          
      .wr_clk(clkHigh),                      
      .rd_clk(clkLow),                     
      .din(data_out_lrc_wr),        
      .wr_en(data_out_lrc_wr_valid),

      .dout(data_out_lrc_sync),                 
      .rd_en((~data_out_lrc_empty) && S_AXIS_S2MM_tready),               
     
      //可选
      .full(data_out_lrc_full),                   // output wire full
      .empty(data_out_lrc_empty),                 // output wire empty
      .wr_rst_busy(data_out_lrc_wr_rst_busy),     // output wire wr_rst_busy
      .rd_rst_busy(data_out_lrc_rd_rst_busy)      // output wire rd_rst_busy
    );

    assign data_out_lrc_valid_sync = ~data_out_lrc_empty;

endmodule
