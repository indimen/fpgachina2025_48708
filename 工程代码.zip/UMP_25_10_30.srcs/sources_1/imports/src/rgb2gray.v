`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/15 16:05:50
// Design Name: 
// Module Name: rgb2gray
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module rgb2gray(
    input   clk,
    input   rstn,
    
    input   [23:0] data_in,
    input          data_in_valid,
    
    output  [7:0]    data_out,
    output  reg     data_out_valid
    );
    reg [15:0]  r_tmp;
    reg [15:0]  g_tmp;
    reg [15:0]  b_tmp;
    reg [15:0]  gray_tmp;
    
    localparam [7:0] CR = 8'd77;
    localparam [7:0] CG = 8'd150;
    localparam [7:0] CB = 8'd29;
    
    always@(posedge clk,negedge rstn)begin
        if(~rstn)begin
            r_tmp <= 0; g_tmp <= 0; b_tmp <= 0;
        end
        else if(data_in_valid == 1'b1) begin
           (* use_dsp = "yes" *) r_tmp <= data_in[23:16] * CR;
           (* use_dsp = "yes" *) g_tmp <= data_in[15: 8] * CG;
           (* use_dsp = "yes" *) b_tmp <= data_in[ 7: 0] * CB;
        end
    end
    
   always@(posedge clk,negedge rstn)begin
        if(~rstn)begin
            gray_tmp <= 0;
        end
        else  begin
            gray_tmp <= r_tmp + g_tmp + b_tmp;
        end
    end
    
    assign data_out = gray_tmp[15:8];
    
    reg delay_data_in_valid;
    always@(posedge clk ,negedge rstn)begin
        if(~rstn)begin
            delay_data_in_valid <= 0;
            data_out_valid <= 0;
        end
        else begin
            delay_data_in_valid <= data_in_valid;
            data_out_valid <= delay_data_in_valid;
        end
    end
    
endmodule

