`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/22 20:41:36
// Design Name: 
// Module Name: aggr_new
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`define P1 100
`define P2_ 400
`define MAX_DISP 64

module aggregation #(
    parameter IS_LEFT = 1
)(
        input clk,
        input rst_n,
        input [`MAX_DISP*5-1:0] data_in_cost,
        input [7:0] data_in_gray,
        input data_in_valid,
        output reg data_rx_ready,
        output [5:0] disp_aggr,
        output reg data_tx_ready
    );
    //============= data_rx_ready ==============
    localparam DELAY_CYCLE = 10;
    localparam High  = 375;
    localparam Width = 450;
    reg [3:0] delay_cycle_counter;
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)begin
            delay_cycle_counter <= 0;
            data_rx_ready       <= 0;
        end
        else if(delay_cycle_counter == DELAY_CYCLE-1)begin
            delay_cycle_counter <= 0;
            data_rx_ready       <= 1;
        end
        else if(data_in_valid == 1'b1)begin
            delay_cycle_counter <= delay_cycle_counter + 1'd1;
            data_rx_ready       <= 0;
        end
    end
    reg delay_cycle_counter_pre_valid;
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)
            delay_cycle_counter_pre_valid <= 0;
        else if(delay_cycle_counter == DELAY_CYCLE-1-2)begin
            delay_cycle_counter_pre_valid       <= 1;
        end
        else begin
            delay_cycle_counter_pre_valid       <= 0;
        end
    end
    //aggr image position counter
    reg [9:0] aggr_image_x_pos; //640 max
    reg [8:0] aggr_image_y_pos; //480 max
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)
            aggr_image_x_pos <= 0;
        else if( aggr_image_x_pos == Width-1 && data_rx_ready ==1'b1)
            aggr_image_x_pos <= 0;
        else if(data_rx_ready ==1'b1)
            aggr_image_x_pos <= aggr_image_x_pos + 1'd1;
    end
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)
            aggr_image_y_pos <= 0;
        else if( aggr_image_y_pos == High-1 && aggr_image_x_pos == Width-1 && data_rx_ready ==1'b1)
            aggr_image_y_pos <= 0;
        else if(data_rx_ready ==1'b1 && aggr_image_x_pos == Width-1)
            aggr_image_y_pos <= aggr_image_y_pos + 1'd1;
    end
    //============== gray image Cache ============================
    reg [7:0] last_data_gray_reg;
    reg [7:0] last_data_gray;
    
    integer i;
    reg [`MAX_DISP*10-1:0] last_state_cost_vec;//10 bits to handle T4 values up to 431
    reg [`MAX_DISP*10-1:0] cost_aggr;//10 bits to handle aggregated costs
    
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)
            last_data_gray_reg <=0;
        else if(delay_cycle_counter_pre_valid == 1'b1)
            last_data_gray_reg <= data_in_gray;
    end
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)begin
            last_data_gray <=0;
            last_state_cost_vec<=640'b11;
        end
        else if(aggr_image_x_pos == 0 && data_in_valid == 1'b1)begin
            last_data_gray <= data_in_gray;
            for(i=0;i<`MAX_DISP;i=i+1) begin
                last_state_cost_vec[i*10+:10] <= {5'b00000, data_in_cost[i*5+:5]};
            end
        end
        else if(data_rx_ready == 1'b1 && data_in_valid == 1'b1)begin
            last_data_gray <= last_data_gray_reg;
            last_state_cost_vec <= cost_aggr;
        end
    end 

    wire [8:0] P2;
    reg [7:0] gray_grad;//0-255
    always@(posedge clk ,negedge rst_n)begin
        if(!rst_n)begin
            gray_grad <= 0;
        end
        else begin
             if(data_in_gray > last_data_gray)
                gray_grad <= data_in_gray - last_data_gray;
            else
                gray_grad <= last_data_gray - data_in_gray;
        end
    end
    //MUX, avoid division operation
    assign P2 = (gray_grad>=4)? `P1 :
                ((gray_grad==3)? 'd133 : 
                ((gray_grad==2)? 'd200:'d400));
    //==============
//    integer i;
//    reg [`MAX_DISP*10-1:0] last_state_cost_vec;//10 bits to handle T4 values up to 431
//    reg [`MAX_DISP*10-1:0] cost_aggr;//10 bits to handle aggregated costs
//    always@(posedge clk,negedge rst_n)begin
//        if(~rst_n)
//            last_state_cost_vec<=640'b1;
//        else if(aggr_image_x_pos == 0) begin
//            for(i=0;i<`MAX_DISP;i=i+1) begin
//                last_state_cost_vec[i*10+:10] <= {5'b00000, data_in_cost[i*5+:5]};
//            end
//        end 
//        else if(data_rx_ready == 1)
//            last_state_cost_vec <= cost_aggr;
//    end
    //============== 5 level
    //============== the minimum value of the previous state of the cost ============================
    reg [9:0]   min0[0:31];//64 max_disp / 2 = 32
    reg [9:0]   min1[0:15];//32 / 2 = 16
    reg [9:0]   min2[0:7]; //16 / 2 = 8
    reg [9:0]   min3[0:3]; //8 / 2 = 4
    reg [9:0]   min4[0:1]; //4 / 2 = 2
    //last_state_cost_min come out with last_state_cost_vec
    //so we cal the cost_aggr_min/data_in_cost_min
    reg [9:0]   last_state_cost_min;
    //0-63
    reg [5:0]  min0_index[0:31];
    reg [5:0]  min1_index[0:15];
    reg [5:0]  min2_index[0:7];
    reg [5:0]  min3_index[0:3];
    reg [5:0]  min4_index[0:1];
    reg [5:0]  min_index;
     
    always@(posedge clk,negedge rst_n)begin
        if(~rst_n)begin
            for(i=0;i<32;i=i+1)begin
                min0[i] <= 0;
                min0_index[i] <= 0;
            end
            for(i=0;i<16;i=i+1)begin
                min1[i] <= 0;
                min1_index[i] <= 0;
            end
            for(i=0;i<8;i=i+1)begin
                min2[i] <= 0;
                min2_index[i] <= 0;
            end
            for(i=0;i<4;i=i+1)begin
                min3[i] <= 0;
                min3_index[i] <= 0;
            end
            for(i=0;i<2;i=i+1)begin
                min4[i] <= 0;
                min4_index[i] <= 0;
            end
            last_state_cost_min <= 0;
            min_index <= 0;
        end
        else begin
            if(aggr_image_x_pos == 0)begin
                //===== min0 ===============
                for(i=0;i<32;i=i+1)begin
                    if(data_in_cost[(2*i)*5+:5]>data_in_cost[(2*i+1)*5+:5])begin
                        min0[i] <= {5'b00000,data_in_cost[(2*i+1)*5+:5]};
                        min0_index[i]<=2*i+1;
                    end
                    else begin
                        min0[i] <= {5'b00000,data_in_cost[(2*i)*5+:5]};
                        min0_index[i]<=2*i;
                    end   
                end
                //===== min1 ===============
                for(i=0;i<16;i=i+1)begin
                    if(min0[(2*i)]>min0[(2*i+1)])begin
                        min1[i] <= min0[(2*i+1)];
                        min1_index[i]<=min0_index[(2*i+1)];
                    end
                    else begin
                        min1[i] <= min0[(2*i)];
                        min1_index[i]<=min0_index[(2*i)];
                    end   
                end
                //===== min2 ===============
                for(i=0;i<8;i=i+1)begin
                    if(min1[(2*i)]>min1[(2*i+1)])begin
                        min2[i] <= min1[(2*i+1)];
                        min2_index[i]<=min1_index[(2*i+1)];
                    end
                    else begin
                        min2[i] <= min1[(2*i)];
                        min2_index[i]<=min1_index[(2*i)];
                    end   
                end
                //===== min3 ===============
                for(i=0;i<4;i=i+1)begin
                    if(min2[(2*i)]>min2[(2*i+1)])begin
                        min3[i] <= min2[(2*i+1)];
                        min3_index[i]<=min2_index[(2*i+1)];
                    end
                    else begin
                        min3[i] <= min2[(2*i)];
                        min3_index[i]<=min2_index[(2*i)];
                    end   
                end
                //===== min4 ===============
                for(i=0;i<2;i=i+1)begin
                    if(min3[(2*i)]>min3[(2*i+1)])begin
                        min4[i] <= min3[(2*i+1)];
                        min4_index[i]<=min3_index[(2*i+1)];
                    end
                    else begin
                        min4[i] <= min3[(2*i)];
                        min4_index[i]<=min3_index[(2*i)];
                    end   
                end
                //last_state_cost_min
                if(min4[0]>min4[1])begin
                    last_state_cost_min <=min4[1];
                    min_index<=min4_index[1];
                end
                else begin
                    last_state_cost_min <=min4[0];
                    min_index<=min4_index[0];
                end 
            end
            else begin
                //===== min0 ===============
                for(i=0;i<32;i=i+1)begin
                    if(last_state_cost_vec[(2*i)*10+:10]>last_state_cost_vec[(2*i+1)*10+:10])begin
                        min0[i] <= last_state_cost_vec[(2*i+1)*10+:10];
                        min0_index[i]<=2*i+1;
                    end
                    else begin
                        min0[i] <= last_state_cost_vec[(2*i)*10+:10];
                        min0_index[i]<=2*i;
                    end   
                end
                //===== min1 ===============
                for(i=0;i<16;i=i+1)begin
                    if(min0[(2*i)]>min0[(2*i+1)])begin
                        min1[i] <= min0[(2*i+1)];
                        min1_index[i]<=min0_index[(2*i+1)];
                    end
                    else begin
                        min1[i] <= min0[(2*i)];
                        min1_index[i]<=min0_index[(2*i)];
                    end   
                end
                //===== min2 ===============
                for(i=0;i<8;i=i+1)begin
                    if(min1[(2*i)]>min1[(2*i+1)])begin
                        min2[i] <= min1[(2*i+1)];
                        min2_index[i]<=min1_index[(2*i+1)];
                    end
                    else begin
                        min2[i] <= min1[(2*i)];
                        min2_index[i]<=min1_index[(2*i)];
                    end   
                end
                //===== min3 ===============
                for(i=0;i<4;i=i+1)begin
                    if(min2[(2*i)]>min2[(2*i+1)])begin
                        min3[i] <= min2[(2*i+1)];
                        min3_index[i]<=min2_index[(2*i+1)];
                    end
                    else begin
                        min3[i] <= min2[(2*i)];
                        min3_index[i]<=min2_index[(2*i)];
                    end   
                end
                //===== min4 ===============
                for(i=0;i<2;i=i+1)begin
                    if(min3[(2*i)]>min3[(2*i+1)])begin
                        min4[i] <= min3[(2*i+1)];
                        min4_index[i]<=min3_index[(2*i+1)];
                    end
                    else begin
                        min4[i] <= min3[(2*i)];
                        min4_index[i]<=min3_index[(2*i)];
                    end   
                end
                //last_state_cost_min
                if(min4[0]>min4[1])begin
                    last_state_cost_min <=min4[1];
                    min_index<=min4_index[1];
                end
                else begin
                    last_state_cost_min <=min4[0];
                    min_index<=min4_index[0];
                end
            end
        end
    end

    // assign disp_aggr = (aggr_image_x_pos <= `MAX_DISP) ? `MAX_DISP - 1 : min_index + 1;
    assign disp_aggr = IS_LEFT ?
        ((aggr_image_x_pos <= `MAX_DISP) ? `MAX_DISP - 1 : min_index ) :
        ((aggr_image_x_pos >= (Width - `MAX_DISP)) ? `MAX_DISP -1 : min_index );
    // assign disp_aggr = min_index + 1;

    always@(posedge clk,negedge rst_n)begin
        if(~rst_n)begin
            data_tx_ready <= 0;
        end
        else if(delay_cycle_counter == DELAY_CYCLE-5)begin
            data_tx_ready <= 1;
        end
        else
            data_tx_ready <= 0;
    end

    //============== T1 ================
    reg [`MAX_DISP*10-1:0] T1; //T1 needs 9-bit (0-431 for 5x5 window)
    always@(posedge clk ,negedge rst_n)begin
        if(!rst_n)begin
            T1 <= 0;
        end
        else if(aggr_image_x_pos == 0)begin
            for(i=0;i<`MAX_DISP;i=i+1)begin
                T1[i*10+:10] <= {5'b00000,data_in_cost[i*5+:5]};
            end 
        end
        else begin
            T1[9:0] <= 10'd0;
            T1[`MAX_DISP*10-1:(`MAX_DISP-1)*10] <= 10'd0;
            for(i=1;i<`MAX_DISP-1;i=i+1)begin
                T1[i*10+:10] <= last_state_cost_vec[i*10+:10]; //take lower 9 bits
            end 
        end
    end
    //======== T2 ================
    reg [`MAX_DISP*10-1:0] T2; 
    always@(posedge clk ,negedge rst_n)begin
        if(!rst_n)begin
            T2 <= 0;
        end
        else if(aggr_image_x_pos == 0)begin
            for(i=0;i<`MAX_DISP;i=i+1)begin
                T2[i*10+:10] <= {5'b00000,data_in_cost[i*5+:5]}+`P1;
            end   
        end
        else begin
            T2[9:0] <= 10'd0; 
            T2[`MAX_DISP*10-1:(`MAX_DISP-1)*10] <= 10'd0;
            for(i=1;i<`MAX_DISP-1;i=i+1)begin
                T2[i*10+:10] <= last_state_cost_vec[(i-1)*10+:10]+`P1; 
            end   
        end
    end   
    //======== T3 ================
    reg [`MAX_DISP*10-1:0] T3; 
    always@(posedge clk ,negedge rst_n)begin
        if(!rst_n)begin
            T3 <= 0;
        end
        else if(aggr_image_x_pos == 0)begin
            for(i=0;i<`MAX_DISP;i=i+1)begin
                T3[i*10+:10] <= {5'b00000,data_in_cost[i*5+:5]}+`P1;
            end   
        end
        else begin
            T3[9:0] <= 10'd0;
            T3[`MAX_DISP*10-1:(`MAX_DISP-1)*10] <= 10'd0;
            for(i=1;i<`MAX_DISP-1;i=i+1)begin
                T3[i*10+:10] <= last_state_cost_vec[(i+1)*10+:10]+`P1; //take lower 9 bits
            end 
        end  
    end 
    //============ T4 ================================
    reg [`MAX_DISP*10-1:0] T4; 
    always@(posedge clk ,negedge rst_n)begin
        if(!rst_n)begin
            T4 <= 0;
        end
        else begin
            T4[9:0] <= 10'd0;
            T4[`MAX_DISP*10-1:(`MAX_DISP-1)*10] <= 10'd0;
            for(i=1;i<`MAX_DISP-1;i=i+1)begin
                T4[i*10+:10] <= last_state_cost_min + P2;
            end   
        end
    end 
    //=============== MIN(T1,T2,T3,T4) =========================
    reg [`MAX_DISP*10-1:0] T12_min; //9-bit to handle max values
    reg [`MAX_DISP*10-1:0] T34_min; //9-bit to handle max values
    reg [`MAX_DISP*10-1:0] T1234_min; //9-bit to handle max values
    always@(posedge clk ,negedge rst_n)begin
        if(!rst_n)begin
            T12_min <= 0;
        end
        else begin
            for(i=0;i<`MAX_DISP;i=i+1)begin
                if(T1[i*10+:10]>T2[i*10+:10])
                    T12_min[i*10+:10] <= T2[i*10+:10];
                else
                    T12_min[i*10+:10] <= T1[i*10+:10];
            end 
        end 
    end
    always@(posedge clk ,negedge rst_n)begin
        if(!rst_n)begin
            T34_min <= 0;
        end
        else begin
            for(i=0;i<`MAX_DISP;i=i+1)begin
                if(T3[i*10+:10]>T4[i*10+:10])
                    T34_min[i*10+:10] <= T4[i*10+:10];
                else
                    T34_min[i*10+:10] <= T3[i*10+:10];
                end 
        end 
    end
    always@(posedge clk ,negedge rst_n)begin
        if(!rst_n)begin
            T1234_min <= 0;
        end
        else begin
            for(i=0;i<`MAX_DISP;i=i+1)begin
                if(T12_min[i*10+:10]>T34_min[i*10+:10])
                    T1234_min[i*10+:10] <=T34_min[i*10+:10];
                else
                    T1234_min[i*10+:10] <=T12_min[i*10+:10];
            end  
        end 
    end
    //====================== cost_aggr =======================
    always@(posedge clk ,negedge rst_n)begin
        if(!rst_n)begin
            cost_aggr <= 0;
        end
        else begin
            cost_aggr[9:0]<=10'd1023;
            cost_aggr[`MAX_DISP*10-1:(`MAX_DISP-1)*10] <= 10'd1023;
            for(i=1;i<`MAX_DISP-1;i=i+1)begin
                cost_aggr[i*10+:10] <= {5'b00000,data_in_cost[i*5+:5]} + T1234_min[i*10+:10] - last_state_cost_min;
            end
        end                 
    end
    
    genvar p;
    wire [9:0] COST_AGGR_WIRE [0:`MAX_DISP-1];
    generate 
        for(p=0;p<`MAX_DISP;p=p+1)begin
            assign COST_AGGR_WIRE[`MAX_DISP-1-p] = cost_aggr[p*10+:10];
        end
    endgenerate

endmodule
