`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////

`define MAX_DISP 64
`define H 375
`define W 450
module hamming_cost(
    input clk,
    input rst_n,
    
    input   [24:0] data_in_L,
    input   [24:0] data_in_R,
    input          data_in_L_valid,
    input          data_in_R_valid,
    
    output  [`MAX_DISP*5-1:0] data_out,//cost space 
    output  reg           data_out_valid
    
    );
    
    reg [9:0] x_pos;
    reg [9:0] y_pos;
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)
            x_pos <= 0;
        else if( x_pos == `W-1  && data_out_valid ==1'b1)
            x_pos <= 0;
        else if(data_out_valid == 1'b1)
            x_pos <= x_pos + 1'b1;
    end
    
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)
            y_pos <= 0;
        else if( y_pos == `H-1 && x_pos == `W-1 && data_out_valid ==1'b1)
            y_pos <= 0;
        else if(x_pos == `W-1 && data_out_valid ==1'b1)
            y_pos <= y_pos + 1'b1;
    end

    //wire pos_valid = (x_pos >= `MAX_DISP-1) ? 1'b1 : 1'b0; // when x_pos > MAX_DISP-1, the output is valid

    //============cache right census vector and shift register ========================
    integer i;
    reg [24:0] census_array_R [0:`MAX_DISP-1];
    always@(posedge clk,negedge rst_n)begin
        if(~rst_n)begin
            for (i=0;i<`MAX_DISP;i=i+1)begin
                census_array_R[i]<=0;
            end
        end
        else if(data_in_R_valid == 1'b1)begin
            census_array_R[0]<=data_in_R;
            for (i=1;i<`MAX_DISP;i=i+1)begin
                census_array_R[i]<=census_array_R[i-1];//shift register
            end
        end    
    end
     //============== parallel xor operation for MAX_DISP => 1 ======================
    //��cause data_in_L and data_in_R census values are mapping
    //but the Sequential Logic make it delay one cycle
    //so we need to map the census index to the correct position
    reg  [24:0] hamming_distance_vec[0:`MAX_DISP-1];
    reg  [24:0] data_in_L_delay;
    always@(posedge clk,negedge rst_n)begin
       if(~rst_n)begin
            data_in_L_delay<=0;
       end
       else if(data_in_L_valid == 1'b1)begin
            data_in_L_delay<=data_in_L;
       end
    end

    always@(posedge clk,negedge rst_n)begin
       if(~rst_n)begin
            for (i=0;i<`MAX_DISP;i=i+1)begin
                hamming_distance_vec[i]<=0;
            end
       end
       else if(data_in_L_valid == 1'b1)begin
            for (i=0;i<`MAX_DISP;i=i+1)begin
                hamming_distance_vec[i]<=data_in_L_delay ^ census_array_R[i];
            end
       end
    end
   //============== 5 level add tree ======================     
    reg [1:0] add0[0:`MAX_DISP-1][0:12];
    reg [2:0] add1[0:`MAX_DISP-1][0:6];
    reg [3:0] add2[0:`MAX_DISP-1][0:3];
    reg [4:0] add3[0:`MAX_DISP-1][0:1];
    reg [4:0] add4[0:`MAX_DISP-1];
    integer disp_index,add_index;
    always@(posedge clk ,negedge rst_n)begin
        //reset
        if(!rst_n)begin
            for(disp_index=0;disp_index<`MAX_DISP;disp_index=disp_index+1)begin
                for(add_index=0;add_index<13;add_index=add_index+1)begin
                    add0[disp_index][add_index] <= 0;
                end
                for(add_index=0;add_index<7;add_index=add_index+1)begin
                    add1[disp_index][add_index] <= 0;
                end
                for(add_index=0;add_index<4;add_index=add_index+1)begin
                    add2[disp_index][add_index] <= 0;
                end
                for(add_index=0;add_index<2;add_index=add_index+1)begin
                    add3[disp_index][add_index] <= 0;
                end
                add4[disp_index] <= 0;
            end 
        end
        else begin
            //===== add0 ======
            for(disp_index=0;disp_index<`MAX_DISP;disp_index=disp_index+1)begin//disp_index direction
                for(add_index=0;add_index<12;add_index=add_index+1)begin //add_index within group
                    add0[disp_index][add_index]<=hamming_distance_vec[disp_index][add_index*2]+hamming_distance_vec[disp_index][add_index*2+1];
                end
                    add0[disp_index][12] <= hamming_distance_vec[disp_index][24];
            end
            //===== add1 ======
            for(disp_index=0;disp_index<`MAX_DISP;disp_index=disp_index+1)begin//disp_index direction
                for(add_index=0;add_index<6;add_index=add_index+1)begin //add_index within group
                    add1[disp_index][add_index]<=add0[disp_index][add_index*2]+add0[disp_index][add_index*2+1];
                end
                    add1[disp_index][6] <= add0[disp_index][12];
            end
            //===== add2 ======
            for(disp_index=0;disp_index<`MAX_DISP;disp_index=disp_index+1)begin//disp_index direction
                for(add_index=0;add_index<3;add_index=add_index+1)begin //add_index within group
                    add2[disp_index][add_index]<=add1[disp_index][add_index*2]+add1[disp_index][add_index*2+1];
                end
                    add2[disp_index][3] <= add1[disp_index][6];
            end
            //===== add3 ======
            for(disp_index=0;disp_index<`MAX_DISP;disp_index=disp_index+1)begin//disp_index direction
                for(add_index=0;add_index<2;add_index=add_index+1)begin //add_index within group
                    add3[disp_index][add_index]<=add2[disp_index][add_index*2]+add2[disp_index][add_index*2+1];
                end
            end
            //===== add4 ======
            for(disp_index=0;disp_index<`MAX_DISP;disp_index=disp_index+1)begin//disp_index direction
                add4[disp_index]<=add3[disp_index][0]+add3[disp_index][1];
            end
        end
    end    
    
    //==================== output amplitude ==============
    genvar k;
    generate 
        for(k=0;k<`MAX_DISP;k=k+1)begin
        //    assign data_out[(k+1)*5-1:k*5] = pos_valid ? add4[k] : 0;
            assign data_out[(k+1)*5-1:k*5] = add4[k];
        end
    endgenerate
    
    //============= data_valid delay 7 cycles ==========================
    //Cache + XOR + Add0 + Add1 + Add2 + Add3 + Add4 = 7 cycles
    reg [5:0] delay_data_in_valid;
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)begin
            delay_data_in_valid[5:0] <= 0;
        end
        else begin
            delay_data_in_valid[5:0]<={delay_data_in_valid[4:0],data_in_L_valid};
        end
    end
    always@(posedge clk ,negedge rst_n)begin
        if(~rst_n)begin
            data_out_valid <= 0;
        end
        else begin
            data_out_valid <= delay_data_in_valid[5];
        end
    end
    
endmodule
